# Studentinfo Module Pack 1
Merge into local/studentinfo.
