<?php
// local/studentinfo/edit.php
require_once(__DIR__.'/../../config.php');
require_login();

$context = context_system::instance();
//require_capability('local/studentinfo:edit', $context);

global $DB, $PAGE, $OUTPUT, $SESSION, $USER;
$userid = required_param('userid', PARAM_INT);
$user   = $DB->get_record('user', ['id'=>$userid, 'deleted'=>0], '*', MUST_EXIST);

// ===== Permission model: edit-own always allowed; edit-others needs capability.
$caneditothers = has_capability('local/studentinfo:edit', $context);
if (!$caneditothers && $USER->id != $userid) {
    // Redirect user to their own record if they try to edit someone else.
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$USER->id]), get_string('nopermissions', 'error'));
}

$userid = required_param('userid', PARAM_INT);
$user   = $DB->get_record('user', ['id'=>$userid, 'deleted'=>0], '*', MUST_EXIST);

$PAGE->set_url(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('edit', 'local_studentinfo').': '.fullname($user));
$PAGE->set_heading(get_string('pluginname', 'local_studentinfo'));

$main = $DB->get_record('local_studentinfo', ['userid'=>$userid]);

/* ===================== CHILD ACTIONS & LISTS ===================== */

/** AKADEMIK **/
$acadaction = optional_param('acadaction', '', PARAM_ALPHA); // '' | edit | delete
$acid       = optional_param('acid', 0, PARAM_INT);
$acad_editrec = null;

if ($acadaction === 'delete' && $acid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_academic', ['id'=>$acid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_academic', ['id'=>$acid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_academic']), 'Rekod akademik dipadam.');
}
if ($acadaction === 'edit' && $acid) {
    if ($rec = $DB->get_record('local_student_academic', ['id'=>$acid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $acad_editrec = $rec;
    }
}
$acad_list = $main ? array_values($DB->get_records('local_student_academic', ['studentid'=>$main->id], 'tahun ASC, id ASC')) : [];

/** BAHASA **/
$langaction = optional_param('langaction', '', PARAM_ALPHA); // '' | edit | delete
$lid        = optional_param('lid', 0, PARAM_INT);
$lang_editrec = null;

if ($langaction === 'delete' && $lid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_language', ['id'=>$lid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_language', ['id'=>$lid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_language']), 'Rekod bahasa dipadam.');
}
if ($langaction === 'edit' && $lid) {
    if ($rec = $DB->get_record('local_student_language', ['id'=>$lid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $lang_editrec = $rec;
    }
}
$lang_list = $main ? array_values($DB->get_records('local_student_language', ['studentid'=>$main->id], 'id ASC')) : [];

/** WARIS **/
$faction = optional_param('faction', '', PARAM_ALPHA); // '' | edit | delete
$fid     = optional_param('fid', 0, PARAM_INT);
$fam_editrec = null;

if ($faction === 'delete' && $fid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_family', ['id'=>$fid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_family', ['id'=>$fid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_family']), 'Rekod waris dipadam.');
}
if ($faction === 'edit' && $fid) {
    if ($rec = $DB->get_record('local_student_family', ['id'=>$fid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $fam_editrec = $rec;
    }
}
$fam_list = $main ? array_values($DB->get_records('local_student_family', ['studentid'=>$main->id], 'id ASC')) : [];

/** KURSUS **/
$courseaction = optional_param('courseaction', '', PARAM_ALPHA); // '' | edit | delete
$cid          = optional_param('cid', 0, PARAM_INT);
$course_editrec = null;

if ($courseaction === 'delete' && $cid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_course', ['id'=>$cid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_course', ['id'=>$cid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_courses']), 'Rekod kursus dipadam.');
}
if ($courseaction === 'edit' && $cid) {
    if ($rec = $DB->get_record('local_student_course', ['id'=>$cid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $course_editrec = $rec;
    }
}
$course_list = $main ? array_values($DB->get_records('local_student_course', ['studentid'=>$main->id], 'mula ASC, id ASC')) : [];

/** PANGKAT **/
$rankaction = optional_param('rankaction', '', PARAM_ALPHA); // '' | edit | delete
$rid        = optional_param('rid', 0, PARAM_INT);
$rank_editrec = null;

if ($rankaction === 'delete' && $rid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_rank', ['id'=>$rid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_rank', ['id'=>$rid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_ranks']), 'Rekod pangkat dipadam.');
}
if ($rankaction === 'edit' && $rid) {
    if ($rec = $DB->get_record('local_student_rank', ['id'=>$rid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $rank_editrec = $rec;
    }
}
$rank_list = $main ? array_values($DB->get_records('local_student_rank', ['studentid'=>$main->id], 'tarikh ASC, id ASC')) : [];

/** PERTUKARAN **/
$postaction = optional_param('postaction', '', PARAM_ALPHA); // '' | edit | delete
$pid        = optional_param('pid', 0, PARAM_INT);
$post_editrec = null;

if ($postaction === 'delete' && $pid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_posting', ['id'=>$pid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_posting', ['id'=>$pid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_postings']), 'Rekod pertukaran dipadam.');
}
if ($postaction === 'edit' && $pid) {
    if ($rec = $DB->get_record('local_student_posting', ['id'=>$pid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $post_editrec = $rec;
    }
}
$post_list = $main ? array_values($DB->get_records('local_student_posting', ['studentid'=>$main->id], 'mula ASC, id ASC')) : [];

/** PINGAT **/
$awardaction = optional_param('awardaction', '', PARAM_ALPHA); // '' | edit | delete
$awid        = optional_param('awid', 0, PARAM_INT);
$award_editrec = null;

if ($awardaction === 'delete' && $awid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_award', ['id'=>$awid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_award', ['id'=>$awid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_awards']), 'Rekod pingat dipadam.');
}
if ($awardaction === 'edit' && $awid) {
    if ($rec = $DB->get_record('local_student_award', ['id'=>$awid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $award_editrec = $rec;
    }
}
$award_list = $main ? array_values($DB->get_records('local_student_award', ['studentid'=>$main->id], 'tarikh ASC, id ASC')) : [];

/** INSURAN **/
$insaction = optional_param('insaction', '', PARAM_ALPHA); // '' | edit | delete
$insid     = optional_param('insid', 0, PARAM_INT);
$ins_editrec = null;

if ($insaction === 'delete' && $insid && confirm_sesskey()) {
    if ($rec = $DB->get_record('local_student_insurance', ['id'=>$insid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) {
            $DB->delete_records('local_student_insurance', ['id'=>$insid]);
        }
    }
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>'sec_insurance']), 'Rekod insurans dipadam.');
}
if ($insaction === 'edit' && $insid) {
    if ($rec = $DB->get_record('local_student_insurance', ['id'=>$insid])) {
        if ($main && (int)$rec->studentid === (int)$main->id) $ins_editrec = $rec;
    }
}
$ins_list = $main ? array_values($DB->get_records('local_student_insurance', ['studentid'=>$main->id], 'id ASC')) : [];

/* ===================== BUILD FORM ===================== */
require_once(__DIR__.'/classes/form/edit_form.php');
$mform = new \local_studentinfo\form\edit_form(
    null,
    [
        'user'           => $user,
        // existing
        'acad_list'      => $acad_list,
        'acad_editrec'   => $acad_editrec,
        'lang_list'      => $lang_list,
        'lang_editrec'   => $lang_editrec,
        // new
        'fam_list'       => $fam_list,
        'fam_editrec'    => $fam_editrec,
        'course_list'    => $course_list,
        'course_editrec' => $course_editrec,
        'rank_list'      => $rank_list,
        'rank_editrec'   => $rank_editrec,
        'post_list'      => $post_list,
        'post_editrec'   => $post_editrec,
        'award_list'     => $award_list,
        'award_editrec'  => $award_editrec,
        'ins_list'       => $ins_list,
        'ins_editrec'    => $ins_editrec,
    ]
);

/* ===================== HANDLE SUBMIT ===================== */
if ($mform->is_cancelled()) {
    $tab = optional_param('tab', 'sec_identity', PARAM_ALPHANUMEXT);
    redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid, 'tab'=>$tab]));
} else if ($data = $mform->get_data()) {

    /* AKADEMIK add/update */
    if (!empty($data->acad_submit)) {
        require_sesskey();
        $now = time();
        if (!$main) { $main = (object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id = $DB->insert_record('local_studentinfo', $main); }
        $rid  = (int)($data->acad_id ?? 0);
        $yr   = isset($data->acad_tahun) ? (int)$data->acad_tahun : null;
        $lvl  = trim((string)($data->acad_tahap ?? ''));
        $desc = trim((string)($data->acad_kelulusan ?? ''));
        if ($rid) {
            if ($rec = $DB->get_record('local_student_academic', ['id'=>$rid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->tahun=$yr?:null; $rec->tahap=$lvl?:null; $rec->kelulusan=$desc?:null; $rec->timemodified=$now;
                    $DB->update_record('local_student_academic', $rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid,'tab'=>'sec_academic']), 'Rekod dikemaskini.');
        } else {
            $ins = (object)['studentid'=>$main->id,'tahun'=>$yr?:null,'tahap'=>$lvl?:null,'kelulusan'=>$desc?:null,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_academic',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php', ['userid'=>$userid,'tab'=>'sec_academic']), 'Rekod ditambah.');
        }
    }

    /* BAHASA add/update */
    if (!empty($data->lang_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main = (object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id = $DB->insert_record('local_studentinfo', $main); }
        $lid  = (int)($data->lang_id ?? 0);
        $bah  = trim((string)($data->lang_bahasa ?? ''));
        $baca = trim((string)($data->lang_baca ?? ''));
        $lisan= trim((string)($data->lang_lisan ?? ''));
        $tulis= trim((string)($data->lang_tulis ?? ''));
        if ($lid) {
            if ($rec=$DB->get_record('local_student_language',['id'=>$lid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->bahasa=$bah?:null; $rec->baca=$baca?:null; $rec->lisan=$lisan?:null; $rec->tulis=$tulis?:null; $rec->timemodified=$now;
                    $DB->update_record('local_student_language',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_language']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'bahasa'=>$bah?:null,'baca'=>$baca?:null,'lisan'=>$lisan?:null,'tulis'=>$tulis?:null,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_language',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_language']),'Rekod ditambah.');
        }
    }

    /* WARIS add/update */
    if (!empty($data->fam_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main=(object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id=$DB->insert_record('local_studentinfo',$main); }
        $fid  = (int)($data->fam_id ?? 0);
        $hub  = trim((string)($data->fam_hubungan ?? ''));
        $nama = trim((string)($data->fam_nama ?? ''));
        $ic   = trim((string)($data->fam_ic ?? ''));
        $tel  = trim((string)($data->fam_telefon ?? ''));
        $dob  = (isset($data->fam_tarikh_lahir) && is_numeric($data->fam_tarikh_lahir)) ? (int)$data->fam_tarikh_lahir : 0;
        if ($fid) {
            if ($rec=$DB->get_record('local_student_family',['id'=>$fid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->hubungan=$hub?:null; $rec->nama=$nama?:null; $rec->ic=$ic?:null; $rec->telefon=$tel?:null; $rec->tarikh_lahir=$dob; $rec->timemodified=$now;
                    $DB->update_record('local_student_family',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_family']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'hubungan'=>$hub?:null,'nama'=>$nama?:null,'ic'=>$ic?:null,'telefon'=>$tel?:null,'tarikh_lahir'=>$dob,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_family',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_family']),'Rekod ditambah.');
        }
    }

    /* KURSUS add/update */
    if (!empty($data->course_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main=(object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id=$DB->insert_record('local_studentinfo',$main); }
        $cid  = (int)($data->course_id ?? 0);
        $nama = trim((string)($data->kursus_nama ?? ''));
        $tmp  = trim((string)($data->kursus_tempat ?? ''));
        $mula = (isset($data->kursus_mula)  && is_numeric($data->kursus_mula))  ? (int)$data->kursus_mula  : 0;
        $tmt  = (isset($data->kursus_tamat) && is_numeric($data->kursus_tamat)) ? (int)$data->kursus_tamat : 0;
        $kept = trim((string)($data->kursus_keputusan ?? ''));
        if ($cid) {
            if ($rec=$DB->get_record('local_student_course',['id'=>$cid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->nama=$nama?:null; $rec->tempat=$tmp?:null; $rec->mula=$mula; $rec->tamat=$tmt; $rec->keputusan=$kept?:null; $rec->timemodified=$now;
                    $DB->update_record('local_student_course',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_courses']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'nama'=>$nama?:null,'tempat'=>$tmp?:null,'mula'=>$mula,'tamat'=>$tmt,'keputusan'=>$kept?:null,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_course',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_courses']),'Rekod ditambah.');
        }
    }

    /* PANGKAT add/update */
    if (!empty($data->rank_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main=(object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id=$DB->insert_record('local_studentinfo',$main); }
        $rid = (int)($data->rank_id ?? 0);
        $pgk = trim((string)($data->rank_pangkat ?? ''));
        $dt  = (isset($data->rank_tarikh) && is_numeric($data->rank_tarikh)) ? (int)$data->rank_tarikh : 0;
        $kek = trim((string)($data->rank_kekananan ?? ''));
        $dkk = (isset($data->rank_tarikh_kekananan) && is_numeric($data->rank_tarikh_kekananan)) ? (int)$data->rank_tarikh_kekananan : 0;
        if ($rid) {
            if ($rec=$DB->get_record('local_student_rank',['id'=>$rid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->pangkat=$pgk?:null; $rec->tarikh=$dt; $rec->kekananan=$kek?:null; $rec->tarikh_kekananan=$dkk; $rec->timemodified=$now;
                    $DB->update_record('local_student_rank',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_ranks']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'pangkat'=>$pgk?:null,'tarikh'=>$dt,'kekananan'=>$kek?:null,'tarikh_kekananan'=>$dkk,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_rank',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_ranks']),'Rekod ditambah.');
        }
    }

    /* PERTUKARAN add/update */
    if (!empty($data->post_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main=(object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id=$DB->insert_record('local_studentinfo',$main); }
        $pid = (int)($data->post_id ?? 0);
        $jaw = trim((string)($data->posting_jawatan ?? ''));
        $pas = trim((string)($data->posting_pasukan ?? ''));
        $neg = trim((string)($data->posting_negeri ?? ''));
        $mul = (isset($data->posting_mula)  && is_numeric($data->posting_mula))  ? (int)$data->posting_mula  : 0;
        $tam = (isset($data->posting_tamat) && is_numeric($data->posting_tamat)) ? (int)$data->posting_tamat : 0;
        if ($pid) {
            if ($rec=$DB->get_record('local_student_posting',['id'=>$pid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->jawatan=$jaw?:null; $rec->pasukan=$pas?:null; $rec->negeri=$neg?:null; $rec->mula=$mul; $rec->tamat=$tam; $rec->timemodified=$now;
                    $DB->update_record('local_student_posting',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_postings']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'jawatan'=>$jaw?:null,'pasukan'=>$pas?:null,'negeri'=>$neg?:null,'mula'=>$mul,'tamat'=>$tam,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_posting',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_postings']),'Rekod ditambah.');
        }
    }

    /* PINGAT add/update */
    if (!empty($data->award_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main=(object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id=$DB->insert_record('local_studentinfo',$main); }
        $awid = (int)($data->award_id ?? 0);
        $nm   = trim((string)($data->award_nama ?? ''));
        $sgk  = trim((string)($data->award_singkatan ?? ''));
        $gel  = trim((string)($data->award_gelaran ?? ''));
        $dt   = (isset($data->award_tarikh) && is_numeric($data->award_tarikh)) ? (int)$data->award_tarikh : 0;
        if ($awid) {
            if ($rec=$DB->get_record('local_student_award',['id'=>$awid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->nama=$nm?:null; $rec->singkatan=$sgk?:null; $rec->gelaran=$gel?:null; $rec->tarikh=$dt; $rec->timemodified=$now;
                    $DB->update_record('local_student_award',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_awards']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'nama'=>$nm?:null,'singkatan'=>$sgk?:null,'gelaran'=>$gel?:null,'tarikh'=>$dt,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_award',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_awards']),'Rekod ditambah.');
        }
    }

    /* INSURAN add/update */
    if (!empty($data->ins_submit)) {
        require_sesskey();
        $now=time();
        if (!$main) { $main=(object)['userid'=>$userid,'timecreated'=>$now,'timemodified'=>$now]; $main->id=$DB->insert_record('local_studentinfo',$main); }
        $iid  = (int)($data->ins_id ?? 0);
        $pen  = trim((string)($data->ins_penyedia ?? ''));
        $unit = ($data->ins_jumlah_unit !== '' && $data->ins_jumlah_unit !== null && !is_array($data->ins_jumlah_unit)) ? (int)$data->ins_jumlah_unit : null;
        $polis= trim((string)($data->ins_no_polis ?? ''));
        if ($iid) {
            if ($rec=$DB->get_record('local_student_insurance',['id'=>$iid])) {
                if ((int)$rec->studentid === (int)$main->id) {
                    $rec->penyedia=$pen?:null; $rec->jumlah_unit=$unit; $rec->no_polis=$polis?:null; $rec->timemodified=$now;
                    $DB->update_record('local_student_insurance',$rec);
                }
            }
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_insurance']),'Rekod dikemaskini.');
        } else {
            $ins=(object)['studentid'=>$main->id,'penyedia'=>$pen?:null,'jumlah_unit'=>$unit,'no_polis'=>$polis?:null,'timecreated'=>$now,'timemodified'=>$now];
            $DB->insert_record('local_student_insurance',$ins);
            redirect(new moodle_url('/local/studentinfo/edit.php',['userid'=>$userid,'tab'=>'sec_insurance']),'Rekod ditambah.');
        }
    }

    /* ---------- Main SAVE (profile) ---------- */
    $now = time();
    $scalar_or_null = function($v){return (is_array($v)||is_object($v))?null:$v;};

    // Resolve mirrors (IDs -> names/values)
    if (empty($data->pangkat) && !empty($data->pangkat_sel)) {
        $data->pangkat = $DB->get_field('local_student_lkp_pangkat','name',['id'=>(int)$data->pangkat_sel]) ?: null;
    }
    if (empty($data->perkhidmatan) && !empty($data->perkhidmatan_sel)) {
        $data->perkhidmatan = $DB->get_field('local_student_lkp_perkhidmatan','name',['id'=>(int)$data->perkhidmatan_sel]) ?: null;
    }
    if (empty($data->rejimen) && !empty($data->rejimen_sel)) {
        $data->rejimen = $DB->get_field('local_student_lkp_rejimen','name',['id'=>(int)$data->rejimen_sel]) ?: null;
    }
    if (empty($data->pengambilan) && isset($data->pengambilan_sel) && $data->pengambilan_sel!=='') {
        $data->pengambilan = (string)(int)$data->pengambilan_sel;
    }
    if (empty($data->jenis_tauliah) && isset($data->jenis_tauliah_sel) && $data->jenis_tauliah_sel!=='') {
        $data->jenis_tauliah = (string)$data->jenis_tauliah_sel;
    }

    $record = (object)[
        'id'             => !empty($data->id) ? (int)$data->id : 0,
        'userid'         => (int)$userid,
        'tentera_no'     => $scalar_or_null($data->tentera_no ?? null),
        'pangkat'        => $scalar_or_null($data->pangkat ?? null),
        'perkhidmatan'   => $scalar_or_null($data->perkhidmatan ?? null),
        'rejimen'        => $scalar_or_null($data->rejimen ?? null),
        'pengambilan'    => isset($data->pengambilan) && !is_array($data->pengambilan) ? (string)$data->pengambilan : null,
        'jenis_tauliah'  => $scalar_or_null($data->jenis_tauliah ?? null),
        'tarikh_masuk'   => (isset($data->tarikh_masuk)   && is_numeric($data->tarikh_masuk))   ? (int)$data->tarikh_masuk   : 0,
        'tarikh_tauliah' => (isset($data->tarikh_tauliah) && is_numeric($data->tarikh_tauliah)) ? (int)$data->tarikh_tauliah : 0,
        'tarikh_tamat'   => (isset($data->tarikh_tamat)   && is_numeric($data->tarikh_tamat))   ? (int)$data->tarikh_tamat   : 0,
        'tarikh_lahir'   => (isset($data->tarikh_lahir)   && is_numeric($data->tarikh_lahir))   ? (int)$data->tarikh_lahir   : 0,
        'tempat_lahir'   => $scalar_or_null($data->tempat_lahir ?? null),
        'berat_kg'       => ($data->berat_kg ?? '')!=='' && !is_array($data->berat_kg) ? (float)$data->berat_kg : null,
        'tinggi_m'       => ($data->tinggi_m ?? '')!=='' && !is_array($data->tinggi_m) ? (float)$data->tinggi_m : null,
        'bmi'            => ($data->bmi ?? '')!==''      && !is_array($data->bmi)      ? (float)$data->bmi      : null,
        'darah'          => $scalar_or_null($data->darah ?? null),
        'bangsa'         => $scalar_or_null($data->bangsa ?? null),
        'agama'          => $scalar_or_null($data->agama ?? null),
        'warganegara'    => $scalar_or_null($data->warganegara ?? null),
        'taraf_kahwin'   => $scalar_or_null($data->taraf_kahwin ?? null),
        'telefon'        => $scalar_or_null($data->telefon ?? null),
        'email'          => $scalar_or_null($data->email ?? null),
        'batd11_nilaian' => ($data->batd11_nilaian ?? '')!=='' && !is_array($data->batd11_nilaian) ? (float)$data->batd11_nilaian : null,
        'batd11_tahun'   => (isset($data->batd11_tahun) && !is_array($data->batd11_tahun)) ? (int)$data->batd11_tahun : null,
        'adfelps_listening' => (isset($data->adfelps_listening) && !is_array($data->adfelps_listening)) ? (int)$data->adfelps_listening : null,
        'adfelps_speaking'  => (isset($data->adfelps_speaking)  && !is_array($data->adfelps_speaking))  ? (int)$data->adfelps_speaking  : null,
        'adfelps_reading'   => (isset($data->adfelps_reading)   && !is_array($data->adfelps_reading))   ? (int)$data->adfelps_reading   : null,
        'adfelps_writing'   => (isset($data->adfelps_writing)   && !is_array($data->adfelps_writing))   ? (int)$data->adfelps_writing   : null,
        'passport_no'    => $scalar_or_null($data->passport_no ?? null),
        'passport_expiry'=> (isset($data->passport_expiry) && is_numeric($data->passport_expiry)) ? (int)$data->passport_expiry : 0,
        'negara_dilawati'=> $scalar_or_null($data->negara_dilawati ?? null),
        'hobi'           => $scalar_or_null($data->hobi ?? null),
        'timemodified'   => $now
    ];

    if (!empty($record->berat_kg) && !empty($record->tinggi_m) && $record->tinggi_m > 0) {
        $calc = round($record->berat_kg/($record->tinggi_m*$record->tinggi_m),1);
        if (empty($record->bmi) || abs($record->bmi-$calc)>=0.2) $record->bmi=$calc;
    }

    if (empty($record->id)) {
        $record->timecreated=$now;
        if ($main) { $record->id = $main->id; }
        if (empty($record->id)) { $record->id = $DB->insert_record('local_studentinfo',$record); }
    } else {
        $DB->update_record('local_studentinfo',$record);
    }

    redirect(new moodle_url('/local/studentinfo/view.php', ['userid'=>$userid]), get_string('savechanges','local_studentinfo'));
}

/* ===================== RENDER ===================== */
echo $OUTPUT->header();

// --- One-time modal AFTER header so Bootstrap styles apply.
if (!empty($SESSION->studentgate_showpopup)) {
    ?>
    <div class="modal show" tabindex="-1" role="dialog" style="display:block;background:rgba(0,0,0,.35)">
      <div class="modal-dialog" role="document">
        <div class="modal-content" style="border-radius:12px">
          <div class="modal-header">
            <h5 class="modal-title">Lengkapkan Maklumat Pelajar</h5>
          </div>
          <div class="modal-body">
            <p>Sebelum anda boleh menggunakan portal, sila lengkapkan maklumat pelajar anda.</p>
          </div>
          <div class="modal-footer">
            <a class="btn btn-primary" href="<?php echo (new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$USER->id])); ?>">Lengkapkan Sekarang</a>
          </div>
        </div>
      </div>
    </div>
    <?php
    $SESSION->studentgate_showpopup = 0; // show once
}
?>
<h3 class="mb-3" style="font-weight:600;">
  <span>No Tentera:</span> <?php echo s($main->tentera_no ?? '-'); ?>
  &nbsp;·&nbsp; <span>Pangkat:</span> <?php echo s($main->pangkat ?? '-'); ?>
  &nbsp;·&nbsp; <span>Nama:</span> <?php echo s($user->firstname); ?>
</h3>
<?php
// Preload for form defaults
$set = new \stdClass();
if ($main) { foreach ($main as $k=>$v) { $set->$k=$v; } }
$set->email_display = $user->email;

// Prefill Akademik row
if (!empty($acad_editrec)) {
    $set->acad_id        = $acad_editrec->id;
    $set->acad_tahun     = $acad_editrec->tahun;
    $set->acad_tahap     = $acad_editrec->tahap;
    $set->acad_kelulusan = $acad_editrec->kelulusan;
}
// Prefill Bahasa row
if (!empty($lang_editrec)) {
    $set->lang_id     = $lang_editrec->id;
    $set->lang_bahasa = $lang_editrec->bahasa;
    $set->lang_baca   = $lang_editrec->baca;
    $set->lang_lisan  = $lang_editrec->lisan;
    $set->lang_tulis  = $lang_editrec->tulis;
}
// Prefill Waris row
if (!empty($fam_editrec)) {
    $set->fam_id           = $fam_editrec->id;
    $set->fam_hubungan     = $fam_editrec->hubungan;
    $set->fam_nama         = $fam_editrec->nama;
    $set->fam_ic           = $fam_editrec->ic;
    $set->fam_telefon      = $fam_editrec->telefon;
    $set->fam_tarikh_lahir = $fam_editrec->tarikh_lahir;
}
// Prefill Kursus row
if (!empty($course_editrec)) {
    $set->course_id        = $course_editrec->id;
    $set->kursus_nama      = $course_editrec->nama;
    $set->kursus_tempat    = $course_editrec->tempat;
    $set->kursus_mula      = $course_editrec->mula;
    $set->kursus_tamat     = $course_editrec->tamat;
    $set->kursus_keputusan = $course_editrec->keputusan;
}
// Prefill Pangkat row
if (!empty($rank_editrec)) {
    $set->rank_id                 = $rank_editrec->id;
    $set->rank_pangkat            = $rank_editrec->pangkat;
    $set->rank_tarikh             = $rank_editrec->tarikh;
    $set->rank_kekananan          = $rank_editrec->kekananan;
    $set->rank_tarikh_kekananan   = $rank_editrec->tarikh_kekananan;
}
// Prefill Pertukaran row
if (!empty($post_editrec)) {
    $set->post_id          = $post_editrec->id;
    $set->posting_jawatan  = $post_editrec->jawatan;
    $set->posting_pasukan  = $post_editrec->pasukan;
    $set->posting_negeri   = $post_editrec->negeri;
    $set->posting_mula     = $post_editrec->mula;
    $set->posting_tamat    = $post_editrec->tamat;
}
// Prefill Pingat row
if (!empty($award_editrec)) {
    $set->award_id        = $award_editrec->id;
    $set->award_nama      = $award_editrec->nama;
    $set->award_singkatan = $award_editrec->singkatan;
    $set->award_gelaran   = $award_editrec->gelaran;
    $set->award_tarikh    = $award_editrec->tarikh;
}
// Prefill Insuran row
if (!empty($ins_editrec)) {
    $set->ins_id          = $ins_editrec->id;
    $set->ins_penyedia    = $ins_editrec->penyedia;
    $set->ins_jumlah_unit = $ins_editrec->jumlah_unit;
    $set->ins_no_polis    = $ins_editrec->no_polis;
}

/* ==== Prefill selects from saved TEXT fields (map name -> id/value) ==== */
$trim = function($v){ return is_string($v) ? trim($v) : $v; };
$lookup_id_by_name = function(string $table, ?string $name) use ($DB, $trim) {
    $name = $trim($name);
    if ($name === null || $name === '') return '';
    $id = $DB->get_field_select($table, 'id', 'LOWER(name) = LOWER(:n)', ['n' => $name]);
    return $id ? (int)$id : '';
};
if (!empty($set->pangkat))        { $set->pangkat_sel        = $lookup_id_by_name('local_student_lkp_pangkat',       $set->pangkat); }
if (!empty($set->perkhidmatan))   { $set->perkhidmatan_sel   = $lookup_id_by_name('local_student_lkp_perkhidmatan',  $set->perkhidmatan); }
if (!empty($set->rejimen))        { $set->rejimen_sel        = $lookup_id_by_name('local_student_lkp_rejimen',       $set->rejimen); }
if (!empty($set->pengambilan))    { $set->pengambilan_sel    = (int)$set->pengambilan ?: ''; }
if (!empty($set->jenis_tauliah))  { $set->jenis_tauliah_sel  = (string)$set->jenis_tauliah; }
/* ==== /Prefill selects ==== */

// Pass defaults into form
$mform->set_data($set);

/* ===================== NATIVE TABS (no JS) ===================== */
$activetab = optional_param('tab', 'sec_identity', PARAM_ALPHANUMEXT);

// Define your tabs (key => label). Adjust labels as needed.
$tabdefs = [
    'sec_identity'  => 'Identiti',
    'sec_bio'       => 'Bio',
    'sec_contact'   => 'Kontak',
    'sec_perf'      => 'Prestasi',
    'sec_passport'  => 'Passport',
    'sec_academic'  => 'Akademik',
    'sec_language'  => 'Bahasa',
    'sec_family'    => 'Waris',
    'sec_courses'   => 'Kursus',
    'sec_ranks'     => 'Pangkat',
    'sec_postings'  => 'Pertukaran',
    'sec_awards'    => 'Pingat',
    'sec_insurance' => 'Insurans',
];

$tabs = [];
foreach ($tabdefs as $key => $label) {
    $tabs[] = new \tabobject(
        $key,
        new \moodle_url('/local/studentinfo/edit.php', ['userid' => $userid, 'tab' => $key]),
        $label
    );
}
echo $OUTPUT->tabtree($tabs, $activetab);

// Show ONLY the active fieldset, and force-expand any collapsibles inside it.
$activecssid = 'id_' . $activetab;

// CSS: hide others; show active; expand Moodle collapsibles + Bootstrap collapse inside active.
echo '<style>
  .mform fieldset[id^="id_sec_"]{display:none}
  .mform #' . s($activecssid) . '{display:block}

  /* Force-open Moodle legacy collapsibles inside the active fieldset */
  .mform #' . s($activecssid) . ' fieldset.collapsible .fcontainer{display:block !important}
  .mform #' . s($activecssid) . ' fieldset.collapsible{padding-bottom:.25rem}
  .mform #' . s($activecssid) . ' .collapsible-actions{display:none !important}

  /* Force-open Bootstrap-style collapse blocks inside the active fieldset */
  .mform #' . s($activecssid) . ' .collapse{display:block !important; height:auto !important; visibility:visible !important; opacity:1 !important;}
</style>';

// JS: remove "collapsed" class and fix aria on load (covers cases with inline styles).
echo '<script>
document.addEventListener("DOMContentLoaded", function(){
  var root = document.querySelector(".mform #' . $activecssid . '");
  if(!root) return;

  // Legacy Moodle collapsibles (fieldset.collapsible)
  root.querySelectorAll("fieldset.collapsible").forEach(function(fs){
    fs.classList.remove("collapsed");
    var tog = fs.querySelector(".ftoggler a, legend a");
    if (tog) { tog.setAttribute("aria-expanded","true"); }
    var cont = fs.querySelector(".fcontainer");
    if (cont) { cont.style.display = "block"; cont.style.height = "auto"; }
  });

  // Bootstrap collapse areas inside the active section
  root.querySelectorAll(".collapse").forEach(function(el){
    el.classList.add("show");
    el.style.display = "block";
    el.style.height = "auto";
  });
});
</script>';

// Hide all fieldsets except the active one (by fieldset id).


/* ===================== DISPLAY FORM ===================== */
$mform->display();

echo $OUTPUT->footer();
