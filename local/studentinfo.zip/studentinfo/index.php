<?php
require_once(__DIR__.'/../../config.php');
require_once($CFG->libdir.'/ddllib.php'); // xmldb_table for table_exists()

require_login();
if (!class_exists('\\local_studentinfo\\local\\orgstructure_bridge')) {
    require_once($CFG->dirroot.'/local/studentinfo/classes/local/orgstructure_bridge.php');
}

$ouid = optional_param('ou', 0, PARAM_INT);
$context = context_system::instance();
/** Site admin bypass; others must have view cap */
if (!is_siteadmin()) {
    require_capability('local/studentinfo:view', $context);
}

$PAGE->set_url(new moodle_url('/local/studentinfo/index.php'));
$PAGE->set_context($context);
$PAGE->set_title(get_string('manage', 'local_studentinfo'));
$PAGE->set_heading(get_string('pluginname', 'local_studentinfo'));
$PAGE->requires->css('/local/studentinfo/style.css'); // your style.css

global $DB;

/* ==========================================================
   AJAX endpoint (course modal) — ALWAYS return JSON
   ========================================================== */
$ajax = optional_param('ajax', '', PARAM_ALPHA);
if ($ajax === 'courseinfo') {
    @define('NO_DEBUG_DISPLAY', true);
    // Nuke any buffered output so JSON stays clean.
    while (ob_get_level() > 0) { @ob_end_clean(); }

    $sess = optional_param('sesskey', '', PARAM_ALPHANUM);
    if (!$sess || !confirm_sesskey($sess)) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        echo json_encode(['error' => 'invalid_sesskey']);
        exit;
    }

    $userid   = required_param('userid',   PARAM_INT);
    $courseid = required_param('courseid', PARAM_INT);
    $ouid     = optional_param('ou', 0, PARAM_INT);

    if ($ouid && !\local_studentinfo\local\orgstructure_bridge::user_in_ou($userid, $ouid) && !is_siteadmin()) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(403);
        echo json_encode(['error' => 'not_in_ou']);
        exit;
    }

    try {
        // Enrolments
        $enrols = $DB->get_records_sql("
            SELECT e.enrol, ue.timestart, ue.timeend, ue.status
              FROM {user_enrolments} ue
              JOIN {enrol} e ON e.id = ue.enrolid
             WHERE ue.userid = :u AND e.courseid = :c
        ", ['u'=>$userid, 'c'=>$courseid]);
        $enrolments = array_map(function($e){
            return [
                'enrol'     => $e->enrol,
                'status'    => (int)$e->status,   // 0=active,1=suspended
                'timestart' => (int)$e->timestart,
                'timeend'   => (int)$e->timeend
            ];
        }, $enrols ? array_values($enrols) : []);

        // Grade → pct + 4.00
        $grade = $DB->get_record_sql("
            SELECT gg.finalgrade, gi.grademax
              FROM {grade_items} gi
         LEFT JOIN {grade_grades} gg ON gg.itemid = gi.id AND gg.userid = :u
             WHERE gi.courseid = :c AND gi.itemtype = 'course'
        ", ['u'=>$userid, 'c'=>$courseid]);
        $pct = null; $gpa4 = null;
        if ($grade && $grade->grademax > 0 && $grade->finalgrade !== null) {
            $pct  = round(($grade->finalgrade / $grade->grademax) * 100, 2);
            $gpa4 = round($pct * 0.04, 2);
        }

        // Attendance (only if tables exist)
        $attended = null; $total = null; $attpct = null;
        $mgr = $DB->get_manager();
        if ($mgr->table_exists(new xmldb_table('attendance')) &&
            $mgr->table_exists(new xmldb_table('attendance_sessions')) &&
            $mgr->table_exists(new xmldb_table('attendance_log')) &&
            $mgr->table_exists(new xmldb_table('attendance_statuses'))) {

            $att = $DB->get_record_sql("
                SELECT
                  SUM(CASE WHEN s.acronym IN ('P','L','E') THEN 1 ELSE 0 END) AS attended,
                  COUNT(*) AS total
                FROM {attendance} a
                JOIN {attendance_sessions} ses ON ses.attendanceid = a.id
                JOIN {attendance_log} l        ON l.sessionid      = ses.id
                JOIN {attendance_statuses} s   ON s.id             = l.statusid
               WHERE a.course = :c AND l.studentid = :u
            ", ['c'=>$courseid, 'u'=>$userid]);

            if ($att && $att->total > 0) {
                $attended = (int)$att->attended;
                $total    = (int)$att->total;
                $attpct   = round(($attended * 100.0) / $total, 2);
            }
        }

        $coursename = $DB->get_field('course', 'fullname', ['id'=>$courseid], IGNORE_MISSING);

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'course'     => ['id'=>$courseid, 'name'=>$coursename],
            'enrolments' => $enrolments,
            'grade'      => ['pct'=>$pct, 'gpa4'=>$gpa4],
            'attendance' => ['attended'=>$attended, 'total'=>$total, 'pct'=>$attpct]
        ]);
        exit;

    } catch (\Throwable $e) {
        header('Content-Type: application/json; charset=utf-8');
        http_response_code(500);
        echo json_encode(['error' => 'exception', 'message' => $e->getMessage()]);
        exit;
    }
}

/* =========================
   Normal page HTML starts
   ========================= */
echo $OUTPUT->header();

/* small inline helper CSS for action-card grid + footer button */
echo '
<style>
  .actions-grid.fixed-3 { display:grid; grid-template-columns: repeat(3, 1fr); gap:16px; }
  @media (max-width: 1100px){ .actions-grid.fixed-3 { grid-template-columns: 1fr; } }
  .action-card { display:flex; flex-direction:column; min-height: 170px; position: relative; }
  .action-footer { margin-top:auto; display:flex; justify-content:flex-end; }
</style>
';

/* =====================================================================
   OU filter (persists across links)
   ===================================================================== */
$oulst = [];
if ($DB->get_manager()->table_exists(new xmldb_table('local_org_unit'))) {
    $oulst = $DB->get_records_menu('local_org_unit', ['type' => 'college'], 'name', 'id,name');
}

echo html_writer::start_div('container mb-3');
echo html_writer::start_div('d-flex align-items-center gap-2');
echo html_writer::tag('strong', 'OU: ', ['class'=>'me-2']);
echo html_writer::start_tag('form', ['method'=>'get', 'class'=>'d-flex align-items-center gap-2']);

$ouselect = html_writer::start_tag('select', ['name'=>'ou','class'=>'form-control','style'=>'min-width:260px', 'onchange'=>'this.form.submit()']);
$ouselect .= html_writer::tag('option', '— All OUs —', ['value'=>0, 'selected'=>($ouid==0?'selected':null)]);
foreach ($oulst as $id=>$name) {
    $ouselect .= html_writer::tag('option', s($name), ['value'=>(int)$id, 'selected'=>((int)$ouid===(int)$id?'selected':null)]);
}
$ouselect .= html_writer::end_tag('select');

// preserve current non-OU filters on OU change
$preserve = [
    'perkhidmatanid' => optional_param('perkhidmatanid', 0, PARAM_INT),
    'rejimenid'      => optional_param('rejimenid', 0, PARAM_INT),
    'course'         => optional_param('course', '', PARAM_RAW_TRIMMED),
];
foreach ($preserve as $k=>$v) {
    $ouselect .= html_writer::empty_tag('input', ['type'=>'hidden','name'=>$k,'value'=>s($v)]);
}
echo $ouselect;
echo html_writer::end_tag('form');
echo html_writer::end_div(); // flex
echo html_writer::end_div(); // container

/* =====================================================================
   MANAGEMENT (Action Cards, 2 rows × 3 cards) — OU-scoped
   ===================================================================== */
echo html_writer::start_div('container mb-3');
echo html_writer::tag('h5', 'Management', ['class' => 'mb-2']);

$cards = [
    [
        'title' => 'Bulk Assign',
        'desc'  => 'CSV → Programme & Intake + add to cohort',
        'url'   => new moodle_url('/local/studentinfo/bulk_assign.php', ['ou' => $ouid]),
        'cap'   => 'local/studentinfo:manage',
        'theme' => 'act-blue',
        'extras'=> []
    ],
    [
      'title' => 'Intake Manager',
      'desc'  => 'Ensure cohorts & sync members',
      'url'   => new moodle_url('/local/studentinfo/intake_manager.php', ['ou' => $ouid]),
      'cap'   => 'local/studentinfo:manage',
      'theme' => 'act-red',
      'extras'=> []
    ],
    [
        'title' => 'GPA Snapshot',
        'desc'  => 'Compute GPA/CGPA from Gradebook (now)',
        'url'   => new moodle_url('/local/studentinfo/gpa_snapshot.php', ['ou' => $ouid]),
        'cap'   => 'local/studentinfo:manage',
        'theme' => 'act-darkblue',
        'extras'=> []
    ],
    [
        'title' => 'Attendance Rollup',
        'desc'  => 'Roll up % from mod_attendance (now)',
        'url'   => new moodle_url('/local/studentinfo/attendance_rollup.php', ['ou' => $ouid]),
        'cap'   => 'local/studentinfo:manage',
        'theme' => 'act-blue',
        'extras'=> []
    ],
    [
        'title' => 'Student Lookup',
        'desc'  => 'Quick summary, CGPA, balance, cases',
        'url'   => new moodle_url('/local/studentinfo/student.php', ['ou' => $ouid]),
        'cap'   => 'local/studentinfo:view',
        'theme' => 'act-red',
        'extras'=> []
    ],
    [
        'title' => 'Manage Leaves',
        'desc'  => 'Submit, approve, and track leave requests',
        'url'   => new moodle_url('/local/leave/', ['ou' => $ouid]),
        'cap'   => 'local/studentinfo:manage',
        'theme' => 'act-darkblue',
        'extras'=> []
    ],
    [
      'title' => 'Fees Console',
      'desc'  => 'Bill intakes, settle payments',
      'url'   => new moodle_url('/local/studentinfo/fees_console.php', ['ou' => $ouid]),
      'cap'   => 'local/studentinfo:finance',
      'theme' => 'act-blue',
      'extras'=> []
    ],
    


];

echo html_writer::start_div('actions-grid fixed-3');
foreach ($cards as $c) {
    if (!is_siteadmin() && !has_capability($c['cap'], $context)) { continue; }

    echo html_writer::start_div('action-card '.$c['theme']);
    echo html_writer::div(s($c['title']), 'action-title');
    echo html_writer::div(s($c['desc']),  'action-desc');

    if (!empty($c['extras'])) {
        $btns = [];
        foreach ($c['extras'] as $x) {
            $btns[] = html_writer::link($x['url'], s($x['label']), ['class'=>'action-cta']);
        }
        echo html_writer::div(implode(' ', $btns), 'action-cta-group');
    }

    echo html_writer::start_div('action-footer');
    echo html_writer::link($c['url'], 'Open', ['class'=>'action-cta']);
    echo html_writer::end_div(); // .action-footer
    echo html_writer::end_div(); // .action-card
}
echo html_writer::end_div();   // .actions-grid
echo html_writer::end_div();   // .container

/* =====================================================================
   DASHBOARD CARDS (OU-scoped)
   ===================================================================== */
$paramscards = [];
$oujoin_user = '';
$oujoin_user2 = '';
$oujoin_case = '';
if ($ouid) {
    $paramscards['ou'] = $ouid;
    $oujoin_user  = " JOIN {local_org_member} om ON om.userid = sp.userid AND om.orgunitid = :ou ";
    $oujoin_user2 = " JOIN {local_org_member} om ON om.userid = v.userid AND om.orgunitid = :ou ";
    $oujoin_case  = " JOIN {local_org_member} om ON om.userid = c.userid AND om.orgunitid = :ou ";
}

echo '<hr><h5>Statistics</h5>';

$totalactive = $ouid
  ? (int)$DB->get_field_sql("SELECT COUNT(*) FROM {local_studentinfo_studentprog} sp $oujoin_user WHERE sp.status = 'active'", $paramscards)
  : (int)$DB->count_records('local_studentinfo_studentprog', ['status' => 'active']);

$atrisk = $ouid
  ? (int)$DB->get_field_sql("SELECT COUNT(*) FROM {v_studentinfo_atrisk} v $oujoin_user2", $paramscards)
  : (int)$DB->count_records_sql("SELECT COUNT(*) FROM {v_studentinfo_atrisk}");

$outstanding = $ouid
  ? (int)$DB->get_field_sql("SELECT COUNT(*) FROM {v_studentinfo_outstanding} v JOIN {local_org_member} om ON om.userid=v.userid AND om.orgunitid=:ou", $paramscards)
  : (int)$DB->count_records_sql("SELECT COUNT(*) FROM {v_studentinfo_outstanding}");

$opencases = $ouid
  ? (int)$DB->get_field_sql("SELECT COUNT(*) FROM {local_studentinfo_case} c $oujoin_case WHERE c.status IN ('open','in_progress')", $paramscards)
  : (int)$DB->count_records_select('local_studentinfo_case', "status IN ('open','in_progress')", []);

echo html_writer::start_div('container mb-3');
echo html_writer::start_div('row g-3');
$kcard = function($title, $value) {
    return html_writer::div(
        html_writer::div(
            html_writer::tag('div', s($title), ['class' => 'fw-bold']) .
            html_writer::tag('div', s($value), ['class' => 'display-6'])
        , 'p-3 border rounded bg-light shadow-sm'),
        'col-12 col-sm-6 col-lg-3'
    );
};
echo $kcard('Active', $totalactive);
echo $kcard('At risk (GPA/CGPA)', $atrisk);
echo $kcard('Outstanding fees', $outstanding);
echo $kcard('Open cases', $opencases);
echo html_writer::end_div(); // row
echo html_writer::end_div(); // container

/* =====================================================================
   Filters (GET) — now scoped by OU
   ===================================================================== */
$flt_course       = optional_param('course',       '', PARAM_RAW_TRIMMED);
$perkhidmatanid   = optional_param('perkhidmatanid', 0, PARAM_INT);
$rejimenid        = optional_param('rejimenid',      0, PARAM_INT);

/* =====================================================================
   Per-user courses (id+name), OU-scoped
   ===================================================================== */
$csql = "
    SELECT ue.userid, c.id AS courseid, c.fullname
      FROM {user_enrolments} ue
      JOIN {enrol} e ON e.id = ue.enrolid
      JOIN {course} c ON c.id = e.courseid
";
$cswhere = [];
$csparams = [];
if ($ouid) {
    $cswhere[] = "ue.userid IN (SELECT userid FROM {local_org_member} WHERE orgunitid = :ou)";
    $csparams['ou'] = $ouid;
}
$csql .= ($cswhere ? " WHERE ".implode(' AND ', $cswhere) : '');
$csql .= " GROUP BY ue.userid, c.id, c.fullname ORDER BY c.fullname ASC";

$courses_by_user = [];
$rs = $DB->get_recordset_sql($csql, $csparams);
foreach ($rs as $row) {
    $courses_by_user[$row->userid][] = ['id'=>$row->courseid, 'name'=>$row->fullname];
}
$rs->close();

/* =====================================================================
   Lookup filters (Perkhidmatan/Rejimen) — reflect OU by intersecting
   ===================================================================== */
$perkh_list = [];
$rejimen_list = [];

if ($DB->get_manager()->table_exists(new xmldb_table('local_student_lkp_perkhidmatan'))) {
    $all_perkh = $DB->get_records_menu('local_student_lkp_perkhidmatan', null, 'name ASC', 'id,name');
    $pwhere = $ouid ? " WHERE EXISTS (SELECT 1 FROM {local_org_member} om WHERE om.userid = s.userid AND om.orgunitid = :ou)" : "";
    $pnames = $DB->get_fieldset_sql("SELECT DISTINCT s.perkhidmatan FROM {local_studentinfo} s $pwhere", $ouid ? ['ou'=>$ouid] : []);
    foreach ($all_perkh as $id=>$name) {
        if (in_array($name, $pnames, true)) { $perkh_list[$id] = $name; }
    }
}

if ($DB->get_manager()->table_exists(new xmldb_table('local_student_lkp_rejimen'))) {
    $all_rej = $DB->get_records_menu('local_student_lkp_rejimen', null, 'name ASC', 'id,name');
    $conds = [];
    $rparams = [];
    if ($ouid) { $conds[] = "EXISTS (SELECT 1 FROM {local_org_member} om WHERE om.userid = s.userid AND om.orgunitid = :ou)"; $rparams['ou']=$ouid; }
    if ($perkhidmatanid && !empty($perkh_list[$perkhidmatanid])) {
        $conds[] = "s.perkhidmatan COLLATE utf8mb4_unicode_ci = :p";
        $rparams['p'] = $perkh_list[$perkhidmatanid];
    }
    $rwhere = $conds ? (" WHERE ".implode(' AND ',$conds)) : '';
    $rnames = $DB->get_fieldset_sql("SELECT DISTINCT s.rejimen FROM {local_studentinfo} s $rwhere", $rparams);
    foreach ($all_rej as $id=>$name) {
        if (in_array($name, $rnames, true)) { $rejimen_list[$id] = $name; }
    }
}

/* Resolve selected lookup IDs to names for WHERE */
$flt_perkhidmatan = ($perkhidmatanid && !empty($perkh_list[$perkhidmatanid])) ? $perkh_list[$perkhidmatanid] : '';
$flt_rejimen      = ($rejimenid && !empty($rejimen_list[$rejimenid])) ? $rejimen_list[$rejimenid] : '';

/* =====================================================================
   Base data query (OU-scoped)
   ===================================================================== */
$where  = ["u.deleted = 0"];
$params = [];

if ($ouid) {
    $where[] = "EXISTS (SELECT 1 FROM {local_org_member} om WHERE om.userid = u.id AND om.orgunitid = :ou)";
    $params['ou'] = $ouid;
}
if ($flt_perkhidmatan !== '') {
    $where[] = "s.perkhidmatan COLLATE utf8mb4_unicode_ci = :p";
    $params['p'] = $flt_perkhidmatan;
}
if ($flt_rejimen !== '') {
    $where[] = "s.rejimen COLLATE utf8mb4_unicode_ci = :r";
    $params['r'] = $flt_rejimen;
}
if ($flt_course !== '') {
    $where[] = "EXISTS (
        SELECT 1
          FROM {user_enrolments} ue2
          JOIN {enrol} e2 ON ue2.enrolid = e2.id
          JOIN {course} c2 ON c2.id = e2.courseid
         WHERE ue2.userid = u.id
           AND ".$DB->sql_like('c2.fullname', ':crs', false)."
    )";
    $params['crs'] = "%{$flt_course}%";
}

$sql = "
    SELECT
        u.id AS userid,
        u.firstname,
        s.id AS studentid,
        s.tentera_no,
        s.pangkat,
        s.perkhidmatan,
        s.rejimen
    FROM {user} u
    LEFT JOIN {local_studentinfo} s ON s.userid = u.id
    ".(!empty($where) ? "WHERE ".implode(" AND ", $where) : "")."
    ORDER BY u.firstname ASC, u.id ASC
";
$records = $DB->get_records_sql($sql, $params);

/* Summary (Programme/Status/CGPA/Balance/Open cases) */
$summarymap = [];
if ($records) {
    $userids = array_map(fn($r) => $r->userid, $records);
    list($in, $inparams) = $DB->get_in_or_equal($userids, SQL_PARAMS_NAMED);
    $sumrows = $DB->get_records_sql("SELECT * FROM {v_studentinfo_student_summary} WHERE userid $in", $inparams);
    foreach ($sumrows as $sr) { $summarymap[$sr->userid] = $sr; }
}
?>
<link rel="stylesheet" href="https://cdn.datatables.net/v/dt/dt-2.0.8/b-3.1.2/b-html5-3.1.2/b-print-3.1.2/r-3.0.3/datatables.min.css"/>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/v/dt/dt-2.0.8/b-3.1.2/b-html5-3.1.2/b-print-3.1.2/r-3.0.3/datatables.min.js"></script>

<style>
  div.dt-container .dt-paging { text-align: right; }
  div.dt-container .dt-paging .dt-paging-button { float: none; }
  .badge-has { background:#28a745; }
  .badge-new { background:#6c757d; }
  .firstname-badge { font-size: 0.75rem; margin-left: .5rem; vertical-align: middle; }
  #dt-custom-search { text-align: right; }
  .si-modal { position: fixed; inset: 0; background: rgba(0,0,0,.5); display: none; z-index: 1050; }
  .si-modal.show { display: block; }
  .si-modal .si-card { background:#fff; border-radius: .5rem; max-width: 720px; margin: 8vh auto; padding: 1rem 1.25rem; box-shadow: 0 10px 30px rgba(0,0,0,.2); }
  .si-modal .si-close { float:right; cursor:pointer; font-size: 1.25rem; line-height: 1; padding: .25rem .5rem; }
  .si-muted { color:#6c757d; }
  .si-grid { display:grid; grid-template-columns: 1fr 1fr; gap: .75rem 1rem; }
  @media (max-width: 576px){ .si-grid { grid-template-columns: 1fr; } }
  a.si-course-link { text-decoration: underline; cursor: pointer; }
</style>

<div class="container-fluid">

  <hr>
  <div class="d-flex justify-content-between align-items-center mb-2">
    <h4 class="mb-0"><?php echo get_string('manage', 'local_studentinfo'); ?></h4>
    <div class="input-group" style="max-width:420px;">
      <input id="dt-custom-search" type="search" class="form-control" placeholder="Search..." maxlength="100">
      <div class="input-group-append">
        <button id="dt-clear-search" type="button" class="btn btn-outline-secondary">Clear</button>
      </div>
    </div>
  </div>

  <!-- Filter Card -->
  <div class="card mb-3">
    <div class="card-body">
      <form method="get" class="form-row">
        <input type="hidden" name="ou" value="<?php echo (int)$ouid; ?>"/>

        <div class="form-group col-md-3">
          <label>Perkhidmatan</label>
          <select name="perkhidmatanid" class="form-control" onchange="this.form.submit()">
            <option value="0">— Semua —</option>
            <?php foreach ($perkh_list as $id => $name): ?>
              <option value="<?php echo (int)$id; ?>" <?php echo ((int)$id===(int)$perkhidmatanid ? 'selected' : ''); ?>>
                <?php echo s($name); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group col-md-4">
          <label>Rejimen/Kor/Cawang</label>
          <select name="rejimenid" class="form-control" onchange="this.form.submit()">
            <option value="0">— Semua —</option>
            <?php foreach ($rejimen_list as $id => $name): ?>
              <option value="<?php echo (int)$id; ?>" <?php echo ((int)$id===(int)$rejimenid ? 'selected' : ''); ?>>
                <?php echo s($name); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group col-md-3">
          <label>Course (fullname)</label>
          <select name="course" class="form-control" onchange="this.form.submit()">
            <option value="">— Semua —</option>
            <?php
              $allcn = [];
              foreach ($courses_by_user as $uid=>$arr){ foreach ($arr as $c){ $allcn[$c['name']]=true; } }
              $courses_all = array_keys($allcn);
              natcasesort($courses_all);
              foreach ($courses_all as $cname): ?>
              <option value="<?php echo s($cname); ?>" <?php echo ($cname === $flt_course ? 'selected' : ''); ?>>
                <?php echo s($cname); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="form-group col-md-2 d-flex align-items-end">
          <a href="<?php echo new moodle_url('/local/studentinfo/index.php', ['ou'=>$ouid]); ?>" class="btn btn-secondary w-100">Reset</a>
        </div>
      </form>
    </div>
  </div>

  <table id="studentinfo-table" class="table table-striped table-bordered w-100">
    <thead>
      <tr>
        <th>No.</th>
        <th>No Tentera</th>
        <th>Pangkat</th>
        <th>Firstname</th>
        <th>Perkhidmatan</th>
        <th>Rejimen/Kor/Cawang</th>
        <th>Programme</th>
        <th>Status</th>
        <th>CGPA</th>
        <th>Balance (RM)</th>
        <th>Open cases</th>
        <th>Courses</th>
        <th class="no-export">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $i = 1;
        $canedit = has_capability('local/studentinfo:manage', $context) || has_capability('local/studentinfo:edit', $context);
        $sesskey = sesskey();

        foreach ($records as $r):
          $sum = $summarymap[$r->userid] ?? null;

          // Programme column: CODE only
          $programme = ($sum && isset($sum->programme_code)) ? $sum->programme_code : '-';
          $status = $sum->status ?? '-';
          $cgpa   = ($sum && isset($sum->cgpa)) ? number_format((float)$sum->cgpa, 2) : '-';
          $bal    = ($sum && isset($sum->balance)) ? number_format((float)$sum->balance, 2) : '-';
          $oc     = ($sum && isset($sum->opencases)) ? (int)$sum->opencases : 0;

          $badge = ($r->studentid ? '<span class="badge badge-has firstname-badge">HAS</span>' : '<span class="badge badge-new firstname-badge">NEW</span>');

          // Courses column: clickable links
          $courselist = '-';
          if (!empty($courses_by_user[$r->userid])) {
              $links = [];
              foreach (array_unique($courses_by_user[$r->userid], SORT_REGULAR) as $c) {
                  $links[] = '<a href="#" class="si-course-link" data-userid="'.(int)$r->userid
                           . '" data-courseid="'.(int)$c['id']
                           . '" data-coursename="'.s($c['name']).'" data-sesskey="'.$sesskey.'">'
                           . s($c['name']).'</a>';
              }
              $courselist = implode('<br>', $links);
          }

          $viewurl = new moodle_url('/local/studentinfo/view.php', ['userid'=>$r->userid, 'ou'=>$ouid]);
          $editurl = new moodle_url('/local/studentinfo/edit.php', ['userid'=>$r->userid, 'ou'=>$ouid]);
      ?>
        <tr>
          <td><?php echo $i++; ?></td>
          <td><?php echo s($r->tentera_no ?? ''); ?></td>
          <td><?php echo s($r->pangkat ?? ''); ?></td>
          <td><?php echo s($r->firstname) . ' ' . $badge; ?></td>
          <td><?php echo s($r->perkhidmatan ?? ''); ?></td>
          <td><?php echo s($r->rejimen ?? ''); ?></td>
          <td><?php echo s($programme); ?></td>
          <td><?php echo s($status); ?></td>
          <td><?php echo $cgpa; ?></td>
          <td><?php echo $bal; ?></td>
          <td><?php echo $oc; ?></td>
          <td><?php echo $courselist; ?></td>
          <td>
            <?php
              echo html_writer::link($viewurl, 'View Info', ['class'=>'btn btn-sm btn-outline-secondary mr-1']);
              if ($canedit) {
                  echo html_writer::link($editurl, 'Edit Info', ['class'=>'btn btn-sm btn-primary']);
              }
            ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Simple Modal -->
  <div id="si-modal" class="si-modal" aria-hidden="true">
    <div class="si-card">
      <button type="button" class="si-close" aria-label="Close">&times;</button>
      <h5 id="si-modal-title" class="mb-3">Course details</h5>
      <div id="si-modal-body">
        <div class="si-muted">Loading...</div>
      </div>
    </div>
  </div>

</div>

<script>
  (function(){
    const table = new DataTable('#studentinfo-table', {
      paging: true,
      pageLength: 50,
      lengthMenu: [[50, 100, 200, -1], [50, 100, 200, 'All']],
      order: [[3, 'asc']],
      responsive: true,
      dom: 'Brtip',
      buttons: [
        { extend: 'copy',   title: 'Student Info', exportOptions: { columns: ':not(.no-export)' } },
        { extend: 'csv',    title: 'student_info', exportOptions: { columns: ':not(.no-export)' } },
        { extend: 'excel',  title: 'student_info', exportOptions: { columns: ':not(.no-export)' } },
        { extend: 'print',  title: 'Student Info', exportOptions: { columns: ':not(.no-export)' } }
      ],
      columnDefs: [
        { orderable: false, targets: [0, 11, 12] }
      ]
    });

    const ipt = document.getElementById('dt-custom-search');
    const clr = document.getElementById('dt-clear-search');
    if (ipt) ipt.addEventListener('input', () => table.search(ipt.value).draw());
    if (clr) clr.addEventListener('click', () => { ipt.value = ''; table.search('').draw(); });

    const modal = document.getElementById('si-modal');
    const mbody = document.getElementById('si-modal-body');
    const mtitle= document.getElementById('si-modal-title');
    const closeBtn = modal.querySelector('.si-close');
    const showModal = () => modal.classList.add('show');
    const hideModal = () => modal.classList.remove('show');
    closeBtn.addEventListener('click', hideModal);
    modal.addEventListener('click', (e)=>{ if (e.target === modal) hideModal(); });

    document.addEventListener('click', function(e){
      const a = e.target.closest('a.si-course-link');
      if (!a) return;
      e.preventDefault();

      const userid    = a.dataset.userid;
      const courseid  = a.dataset.courseid;
      const coursename= a.dataset.coursename || 'Course';
      const sesskey   = a.dataset.sesskey;
      const ou        = <?php echo (int)$ouid; ?>;

      mtitle.textContent = coursename + ' — details';
      mbody.innerHTML = '<div class="si-muted">Loading...</div>';
      showModal();

      fetch('index.php?ajax=courseinfo&userid=' + encodeURIComponent(userid) +
        '&courseid=' + encodeURIComponent(courseid) +
        '&ou=' + encodeURIComponent(ou) +
        '&sesskey=' + encodeURIComponent(sesskey))
        .then(async (r) => {
          const text = await r.text();
          let j;
          try { j = JSON.parse(text.replace(/^\uFEFF/, '').trim()); } // strip BOM/whitespace
          catch(e){ throw new Error('Bad JSON: ' + text.slice(0, 200)); }
          if (!r.ok || (j && j.error)) {
            throw new Error(j.error || ('HTTP ' + r.status));
          }
          return j;
        })
        .then(j => {
          const enrol = (j.enrolments||[]).map(e => {
            const st = (e.status === 0) ? 'Active' : 'Suspended';
            const ts = e.timestart ? new Date(e.timestart*1000).toLocaleString() : '-';
            const te = e.timeend   ? new Date(e.timeend*1000).toLocaleString()   : '-';
            return `<div><strong>${e.enrol}</strong> — <span class="si-muted">${st}</span><br><small>Start: ${ts} · End: ${te}</small></div>`;
          }).join('') || '<div class="si-muted">No enrolment data.</div>';

          const g = j.grade || {};
          const gline = (g.pct != null)
            ? `<div><strong>GPA (4.00):</strong> ${typeof g.gpa4 === 'number' ? g.gpa4.toFixed(2) : g.gpa4} &nbsp; <small>(${g.pct}% of course total)</small></div>`
            : '<div class="si-muted">No grade yet.</div>';

          const a = j.attendance || {};
          const aline = (a.total != null && a.total > 0)
            ? `<div><strong>Attendance:</strong> ${a.pct}% &nbsp; <small>(${a.attended}/${a.total} sessions)</small></div>`
            : '<div class="si-muted">No attendance records.</div>';

          mbody.innerHTML = `
            <div class="si-grid">
              <div>
                <h6 class="mb-2">Enrolment</h6>
                ${enrol}
              </div>
              <div>
                <h6 class="mb-2">GPA & Attendance</h6>
                ${gline}
                ${aline}
              </div>
            </div>
          `;
        })
        .catch(err => {
          mbody.innerHTML = '<div class="text-danger">Failed to load: ' +
                            (err && err.message ? err.message : 'Unknown error') +
                            '</div>';
        });
    });
  })();
</script>

<?php
echo $OUTPUT->footer();
