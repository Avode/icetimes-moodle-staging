<?php
namespace local_studentinfo\form;

defined('MOODLE_INTERNAL') || die();
require_once($CFG->libdir . '/formslib.php');

class edit_form extends \moodleform {

    public function definition() {
        global $DB;
        $mform = $this->_form;
        $cd    = $this->_customdata ?? [];
        $user  = $cd['user'] ?? null;

        // Existing child data (Akademik & Bahasa).
        $acad         = $cd['acad_list']     ?? [];
        $acad_editrec = $cd['acad_editrec']  ?? null;
        $lang         = $cd['lang_list']     ?? [];
        $lang_editrec = $cd['lang_editrec']  ?? null;

        // NEW child data (Waris, Kursus, Pangkat, Pertukaran, Pingat, Insuran).
        $fam_list       = $cd['fam_list']        ?? [];
        $fam_editrec    = $cd['fam_editrec']     ?? null;
        $course_list    = $cd['course_list']     ?? [];
        $course_editrec = $cd['course_editrec']  ?? null;
        $rank_list      = $cd['rank_list']       ?? [];
        $rank_editrec   = $cd['rank_editrec']    ?? null;
        $post_list      = $cd['post_list']       ?? [];
        $post_editrec   = $cd['post_editrec']    ?? null;
        $award_list     = $cd['award_list']      ?? [];
        $award_editrec  = $cd['award_editrec']   ?? null;
        $ins_list       = $cd['ins_list']        ?? [];
        $ins_editrec    = $cd['ins_editrec']     ?? null;

        // ---------------------------------------------------------------------
        // Hidden keys + active tab
        // ---------------------------------------------------------------------
        $mform->addElement('hidden', 'userid', $user->id ?? 0);
        $mform->setType('userid', PARAM_INT);

        $mform->addElement('hidden', 'id'); // local_studentinfo.id (if exists)
        $mform->setType('id', PARAM_INT);

        $mform->addElement('hidden', 'activetab', 'sec_identity'); // default first tab
        $mform->setType('activetab', PARAM_ALPHANUMEXT);

        // ---------------------------------------------------------------------
        // Identiti
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_identity', get_string('sec_identity', 'local_studentinfo'));

        $mform->addElement('text', 'tentera_no', get_string('tentera_no','local_studentinfo'));
        $mform->setType('tentera_no', PARAM_TEXT);
        $mform->addRule('tentera_no', get_string('required'), 'required', null, 'client');

        $pangkatopts = ['' => '- Pilih -'] + $DB->get_records_menu('local_student_lkp_pangkat', null, 'id ASC', 'id, name');
        $mform->addElement('select', 'pangkat_sel', get_string('pangkat','local_studentinfo'), $pangkatopts);
        $mform->setType('pangkat_sel', PARAM_INT);

        $perkopts = ['' => '- Pilih -'] + $DB->get_records_menu('local_student_lkp_perkhidmatan', null, 'name ASC', 'id, name');
        $mform->addElement('select', 'perkhidmatan_sel', get_string('perkhidmatan','local_studentinfo'), $perkopts);
        $mform->setType('perkhidmatan_sel', PARAM_INT);

        $rejrecs = $DB->get_records('local_student_lkp_rejimen', null, 'name ASC', 'id, perkhidmatanid, name');
        $rejopts = ['' => '- Pilih -'];
        foreach ($rejrecs as $r) { $rejopts[$r->id] = $r->name; }
        $mform->addElement('select', 'rejimen_sel', get_string('rejimen','local_studentinfo'), $rejopts);
        $mform->setType('rejimen_sel', PARAM_INT);

        $yearfrom = 1980; $yearto = (int)date('Y') + 1;
        $years = ['' => '- Tahun -']; for ($y=$yearto; $y >= $yearfrom; $y--) { $years[$y] = (string)$y; }
        $mform->addElement('select', 'pengambilan_sel', get_string('pengambilan','local_studentinfo'), $years);
        $mform->setType('pengambilan_sel', PARAM_INT);

        $jenisopts = ['' => '- Pilih -', 'Tetap'=>'Tetap', 'Jangka Pendek'=>'Jangka Pendek'];
        $mform->addElement('select', 'jenis_tauliah_sel', get_string('jenis_tauliah','local_studentinfo'), $jenisopts);
        $mform->setType('jenis_tauliah_sel', PARAM_TEXT);

        $mform->addElement('date_selector', 'tarikh_masuk', get_string('tarikh_masuk','local_studentinfo'));
        $mform->addElement('date_selector', 'tarikh_tauliah', get_string('tarikh_tauliah','local_studentinfo'));
        $mform->addElement('date_selector', 'tarikh_tamat', get_string('tarikh_tamat','local_studentinfo'));

        // Mirrors (server-side also resolves).
        $mform->addElement('hidden', 'pangkat');       $mform->setType('pangkat', PARAM_TEXT);
        $mform->addElement('hidden', 'perkhidmatan');  $mform->setType('perkhidmatan', PARAM_TEXT);
        $mform->addElement('hidden', 'rejimen');       $mform->setType('rejimen', PARAM_TEXT);
        $mform->addElement('hidden', 'pengambilan');   $mform->setType('pengambilan', PARAM_TEXT);
        $mform->addElement('hidden', 'jenis_tauliah'); $mform->setType('jenis_tauliah', PARAM_TEXT);

        // Sync JS (filter rejimen + set mirrors).
        $rejmap=[]; foreach($rejrecs as $r){$rejmap[$r->id]=(int)$r->perkhidmatanid;}
        $perks=$DB->get_records_menu('local_student_lkp_perkhidmatan',null,'','id,name');
        $pangk=$DB->get_records_menu('local_student_lkp_pangkat',null,'','id,name');
        $rejbyid=[]; foreach($rejrecs as $r){$rejbyid[$r->id]=$r->name;}
        $mform->addElement('html','<script>(function(){const pm='.json_encode($pangk).',sv='.json_encode($perks).',rm='.json_encode($rejmap).',rn='.json_encode($rejbyid).';function g(i){return document.getElementById(i)}const ps=g("id_pangkat_sel"),ks=g("id_perkhidmatan_sel"),rs=g("id_rejimen_sel"),yg=g("id_pengambilan_sel"),js=g("id_jenis_tauliah_sel"),p=g("id_pangkat"),k=g("id_perkhidmatan"),r=g("id_rejimen"),y=g("id_pengambilan"),j=g("id_jenis_tauliah");function sync(){p&&(p.value=(ps&&ps.value&&pm[ps.value])?pm[ps.value]:"");k&&(k.value=(ks&&ks.value&&sv[ks.value])?sv[ks.value]:"");r&&(r.value=(rs&&rs.value&&rn[rs.value])?rn[rs.value]:"");y&&(y.value=(yg&&yg.value)?yg.value:"");j&&(j.value=(js&&js.value)?js.value:"")}function filt(){const id=ks&&ks.value?parseInt(ks.value,10):null;if(!rs)return;Array.from(rs.options).forEach(o=>{if(!o.value){o.hidden=false;return}const rid=parseInt(o.value,10),pid=rm[rid];o.hidden=(id&&pid!==id)});if(rs.value&&rm[parseInt(rs.value,10)]!==id){rs.value=""}}["change","input"].forEach(e=>{ps&&ps.addEventListener(e,sync);ks&&ks.addEventListener(e,function(){filt();sync()});rs&&rs.addEventListener(e,sync);yg&&yg.addEventListener(e,sync);js&&js.addEventListener(e,sync)});filt();sync()})();</script>');

        // ---------------------------------------------------------------------
        // DKT/Bio
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_bio', get_string('sec_bio', 'local_studentinfo'));

        $mform->addElement('date_selector', 'tarikh_lahir', get_string('tarikh_lahir','local_studentinfo'));
        $states=[
            '' => '- Pilih -','Johor'=>'Johor','Kedah'=>'Kedah','Kelantan'=>'Kelantan','Melaka'=>'Melaka','Negeri Sembilan'=>'Negeri Sembilan',
            'Pahang'=>'Pahang','Perak'=>'Perak','Perlis'=>'Perlis','Pulau Pinang'=>'Pulau Pinang','Sabah'=>'Sabah','Sarawak'=>'Sarawak','Selangor'=>'Selangor',
            'Terengganu'=>'Terengganu','Wilayah Persekutuan Kuala Lumpur'=>'Wilayah Persekutuan Kuala Lumpur','Wilayah Persekutuan Putrajaya'=>'Wilayah Persekutuan Putrajaya',
            'Wilayah Persekutuan Labuan'=>'Wilayah Persekutuan Labuan','Luar Malaysia'=>'Luar Malaysia'
        ];
        $mform->addElement('select', 'tempat_lahir', get_string('tempat_lahir','local_studentinfo'), $states); $mform->setType('tempat_lahir', PARAM_TEXT);

        $mform->addElement('float', 'berat_kg', get_string('berat_kg','local_studentinfo')); $mform->setType('berat_kg', PARAM_RAW);
        $mform->addElement('float', 'tinggi_m', get_string('tinggi_m','local_studentinfo')); $mform->setType('tinggi_m', PARAM_RAW);
        $mform->addElement('float', 'bmi', get_string('bmi','local_studentinfo'));           $mform->setType('bmi', PARAM_RAW);

        $mform->addElement('select', 'darah', get_string('darah','local_studentinfo'), [
            '' => '- Pilih -','O+'=>'O+','O-'=>'O-','A+'=>'A+','A-'=>'A-','B+'=>'B+','B-'=>'B-','AB+'=>'AB+','AB-'=>'AB-'
        ]); $mform->setType('darah', PARAM_TEXT);

        $mform->addElement('select', 'bangsa', get_string('bangsa','local_studentinfo'), [
            '' => '- Pilih -','Melayu'=>'Melayu','Cina'=>'Cina','India'=>'India','Iban'=>'Iban','Kadazan-Dusun'=>'Kadazan-Dusun','Bidayuh'=>'Bidayuh','Melanau'=>'Melanau',
            'Bajau'=>'Bajau','Orang Asli'=>'Orang Asli','Bugis'=>'Bugis','Jawa'=>'Jawa','Sino-Native'=>'Sino-Native','Peranakan'=>'Peranakan','Lain-lain'=>'Lain-lain'
        ]); $mform->setType('bangsa', PARAM_TEXT);

        $mform->addElement('select', 'agama', get_string('agama','local_studentinfo'), [
            '' => '- Pilih -','Islam'=>'Islam','Buddha'=>'Buddha','Kristian'=>'Kristian','Hindu'=>'Hindu','Sikh'=>'Sikh','Tao'=>'Tao','Konghucu'=>'Konghucu','Lain-lain'=>'Lain-lain'
        ]); $mform->setType('agama', PARAM_TEXT);

        $mform->addElement('select', 'warganegara', get_string('warganegara','local_studentinfo'),
            ['Malaysia'=>'Malaysia','Bukan Warganegara'=>'Bukan Warganegara']); $mform->setDefault('warganegara','Malaysia'); $mform->setType('warganegara', PARAM_TEXT);

        $mform->addElement('select', 'taraf_kahwin', get_string('taraf_kahwin','local_studentinfo'),
            ['' => '- Pilih -','Berkahwin'=>'Berkahwin','Bujang'=>'Bujang','Duda'=>'Duda','Janda'=>'Janda','Balu'=>'Balu']); $mform->setType('taraf_kahwin', PARAM_TEXT);

        $mform->addElement('html','<script>(function(){const k=document.getElementById("id_berat_kg"),t=document.getElementById("id_tinggi_m"),b=document.getElementById("id_bmi");
        function c(){const w=parseFloat(k&&k.value||""),h=parseFloat(t&&t.value||"");if(!isNaN(w)&&!isNaN(h)&&h>0){const v=w/(h*h);if(b)b.value=(Math.round(v*10)/10).toString();}}
        if(k)k.addEventListener("input",c); if(t)t.addEventListener("input",c);})();</script>');

        // ---------------------------------------------------------------------
        // Kontak
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_contact', get_string('sec_contact', 'local_studentinfo'));
        $mform->addElement('text', 'telefon', get_string('telefon','local_studentinfo')); $mform->setType('telefon', PARAM_TEXT);
        $mform->addElement('text', 'email_display', get_string('email','local_studentinfo'));
        $mform->setType('email_display', PARAM_NOTAGS);
        $mform->freeze('email_display');

        // ---------------------------------------------------------------------
        // Prestasi
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_perf', get_string('sec_perf', 'local_studentinfo'));
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>BAT D11</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $batyears=[''=>'- Tahun -']; for($y=(int)date('Y')+1;$y>=1980;$y--){$batyears[$y]=(string)$y;}
        $mform->addElement('html','<div class="col-md-6">');
        $mform->addElement('select','batd11_tahun','Tahun',$batyears); $mform->setType('batd11_tahun',PARAM_INT);
        $mform->addElement('html','</div><div class="col-md-6">');
        $mform->addElement('text','batd11_nilaian','Nilaian',['size'=>8]); $mform->setType('batd11_nilaian',PARAM_RAW);
        $mform->addElement('html','</div></div></div></div>');

        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>ADFELPS</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $scoreopts=[]; for($i=0;$i<=10;$i++){$scoreopts[$i]=(string)$i;}
        $mform->addElement('html','<div class="col-md-6">');
        $mform->addElement('select','adfelps_listening','Listening',$scoreopts); $mform->setType('adfelps_listening',PARAM_INT); $mform->setDefault('adfelps_listening',0);
        $mform->addElement('select','adfelps_speaking','Speaking',$scoreopts);   $mform->setType('adfelps_speaking',PARAM_INT);  $mform->setDefault('adfelps_speaking',0);
        $mform->addElement('html','</div><div class="col-md-6">');
        $mform->addElement('select','adfelps_reading','Reading',$scoreopts);     $mform->setType('adfelps_reading',PARAM_INT);   $mform->setDefault('adfelps_reading',0);
        $mform->addElement('select','adfelps_writing','Writing',$scoreopts);     $mform->setType('adfelps_writing',PARAM_INT);   $mform->setDefault('adfelps_writing',0);
        $mform->addElement('html','</div></div></div></div>');

        // ---------------------------------------------------------------------
        // AKADEMIK – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_academic', get_string('sec_academic','local_studentinfo'));

        $tablehtml = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
          <table class="table table-sm table-bordered mb-0">
            <thead class="thead-light"><tr>
              <th style="width:12%">Tahun</th>
              <th style="width:22%">Tahap</th>
              <th>Kelulusan / Bidang</th>
              <th style="width:16%">Tindakan</th>
            </tr></thead><tbody>';
        if ($acad) {
            foreach ($acad as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'acadaction'=>'edit',   'acid'=>$r->id], 'pane_sec_academic');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'acadaction'=>'delete', 'acid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_academic');
                $tablehtml .= '<tr>'.
                  '<td>'.s($r->tahun ?? '').'</td>'.
                  '<td>'.s($r->tahap ?? '').'</td>'.
                  '<td>'.s($r->kelulusan ?? '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $tablehtml .= '<tr><td colspan="4" class="text-center text-muted">Tiada rekod akademik.</td></tr>';
        }
        $tablehtml .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $tablehtml);

        // Add/Update Akademik
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Akademik</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden', 'acad_id', $acad_editrec->id ?? 0); $mform->setType('acad_id', PARAM_INT);
        $yearopts=[''=>'- Tahun -']; for($y=(int)date('Y')+1;$y>=1980;$y--){$yearopts[$y]=(string)$y;}
        $tahapopts=[
          '' => '- Tahap -','PHD/Doctorate'=>'PhD / Doctorate','Sarjana'=>'Sarjana','Sarjana Muda'=>'Sarjana Muda','Diploma'=>'Diploma',
          'STPM'=>'STPM','SPM'=>'SPM','SRP/PMR/PT3'=>'SRP / PMR / PT3','UPSR/Penilaian'=>'UPSR / Penilaian','Tidak Bersekolah'=>'Tidak Bersekolah'
        ];
        $mform->addElement('html','<div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tahun</label>');
        $mform->addElement('select','acad_tahun','',$yearopts); $mform->setType('acad_tahun',PARAM_INT);
        $mform->addElement('html','</div></div><div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tahap</label>');
        $mform->addElement('select','acad_tahap','',$tahapopts); $mform->setType('acad_tahap',PARAM_TEXT);
        $mform->addElement('html','</div></div><div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Kelulusan / Bidang</label>');
        $mform->addElement('text','acad_kelulusan','',['size'=>40]); $mform->setType('acad_kelulusan',PARAM_TEXT);
        $mform->addElement('html','</div></div></div>');

        $btngrp = [];
        $btngrp[] = $mform->createElement('submit','acad_submit', empty($acad_editrec)?'Tambah':'Kemaskini');
        $btngrp[] = $mform->createElement('cancel','acad_cancel','Bersih');
        $mform->addGroup($btngrp,'acad_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // BAHASA – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_language', get_string('sec_language','local_studentinfo'));

        $langtable = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
          <table class="table table-sm table-bordered mb-0">
            <thead class="thead-light"><tr>
              <th style="width:22%">Bahasa</th>
              <th style="width:16%">Baca</th>
              <th style="width:16%">Lisan</th>
              <th style="width:16%">Tulis</th>
              <th style="width:16%">Tindakan</th>
            </tr></thead><tbody>';
        if ($lang) {
            foreach ($lang as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'langaction'=>'edit',   'lid'=>$r->id], 'pane_sec_language');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'langaction'=>'delete', 'lid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_language');
                $langtable .= '<tr>'.
                  '<td>'.s($r->bahasa ?? '').'</td>'.
                  '<td>'.s($r->baca ?? '').'</td>'.
                  '<td>'.s($r->lisan ?? '').'</td>'.
                  '<td>'.s($r->tulis ?? '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $langtable .= '<tr><td colspan="5" class="text-center text-muted">Tiada rekod bahasa.</td></tr>';
        }
        $langtable .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $langtable);

        // Add/Update Bahasa
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Bahasa</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden', 'lang_id', $lang_editrec->id ?? 0); $mform->setType('lang_id', PARAM_INT);
        $levelopts = ['' => '- Pilih -', 'FASIH'=>'FASIH', 'BAIK'=>'BAIK', 'LEMAH'=>'LEMAH', 'ASAS'=>'ASAS', 'TIADA'=>'TIADA'];
        $mform->addElement('html','<div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Bahasa</label>');
        $mform->addElement('text','lang_bahasa','',['size'=>20]); $mform->setType('lang_bahasa',PARAM_TEXT);
        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Baca</label>');
        $mform->addElement('select','lang_baca','',$levelopts); $mform->setType('lang_baca',PARAM_TEXT);
        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Lisan</label>');
        $mform->addElement('select','lang_lisan','',$levelopts); $mform->setType('lang_lisan',PARAM_TEXT);
        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tulis</label>');
        $mform->addElement('select','lang_tulis','',$levelopts); $mform->setType('lang_tulis',PARAM_TEXT);
        $mform->addElement('html','</div></div>');

        $btn2=[]; $btn2[]=$mform->createElement('submit','lang_submit', empty($lang_editrec)?'Tambah':'Kemaskini');
        $btn2[]=$mform->createElement('cancel','lang_cancel','Bersih');
        $mform->addGroup($btn2,'lang_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // WARIS – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_family', get_string('sec_family','local_studentinfo'));

        $html = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
        <thead class="thead-light"><tr>
          <th style="width:16%">Hubungan</th>
          <th style="width:22%">Nama</th>
          <th style="width:16%">No. KP</th>
          <th style="width:16%">Telefon</th>
          <th style="width:16%">Tarikh Lahir</th>
          <th style="width:14%">Tindakan</th>
        </tr></thead><tbody>';
        if ($fam_list) {
            foreach ($fam_list as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'faction'=>'edit', 'fid'=>$r->id], 'pane_sec_family');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'faction'=>'delete', 'fid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_family');
                $dob = $r->tarikh_lahir ? userdate($r->tarikh_lahir, get_string('strftimedate','langconfig')) : '';
                $html .= '<tr>'.
                  '<td>'.s($r->hubungan ?? '').'</td>'.
                  '<td>'.s($r->nama ?? '').'</td>'.
                  '<td>'.s($r->ic ?? '').'</td>'.
                  '<td>'.s($r->telefon ?? '').'</td>'.
                  '<td>'.s($dob).'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="6" class="text-center text-muted">Tiada rekod waris.</td></tr>';
        }
        $html .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $html);

        // Add/Update Waris
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Waris</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden', 'fam_id', $fam_editrec->id ?? 0); $mform->setType('fam_id', PARAM_INT);

        $mform->addElement('html','<div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Hubungan</label>');
        $mform->addElement('text','fam_hubungan','',['size'=>18]); $mform->setType('fam_hubungan',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Nama</label>');
        $mform->addElement('text','fam_nama','',['size'=>24]); $mform->setType('fam_nama',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">No. KP</label>');
        $mform->addElement('text','fam_ic','',['size'=>16]); $mform->setType('fam_ic',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Telefon</label>');
        $mform->addElement('text','fam_telefon','',['size'=>16]); $mform->setType('fam_telefon',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tarikh Lahir</label>');
        $mform->addElement('date_selector','fam_tarikh_lahir','');

        $mform->addElement('html','</div></div></div>');
        $g=[]; $g[]=$mform->createElement('submit','fam_submit', empty($fam_editrec)?'Tambah':'Kemaskini');
        $g[]=$mform->createElement('cancel','fam_cancel','Bersih');
        $mform->addGroup($g,'fam_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // KURSUS – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header', 'sec_courses', get_string('sec_courses','local_studentinfo'));

        $html = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
        <thead class="thead-light"><tr>
          <th>Nama Kursus</th>
          <th style="width:18%">Tempat</th>
          <th style="width:14%">Mula</th>
          <th style="width:14%">Tamat</th>
          <th style="width:14%">Keputusan</th>
          <th style="width:14%">Tindakan</th>
        </tr></thead><tbody>';
        if ($course_list) {
            foreach ($course_list as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'courseaction'=>'edit', 'cid'=>$r->id], 'pane_sec_courses');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'courseaction'=>'delete', 'cid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_courses');
                $html .= '<tr>'.
                  '<td>'.s($r->nama ?? '').'</td>'.
                  '<td>'.s($r->tempat ?? '').'</td>'.
                  '<td>'.($r->mula  ? s(userdate($r->mula,  get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td>'.($r->tamat ? s(userdate($r->tamat, get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td>'.s($r->keputusan ?? '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="6" class="text-center text-muted">Tiada rekod kursus.</td></tr>';
        }
        $html .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $html);

        // Add/Update Kursus
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Kursus</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden','course_id',$course_editrec->id ?? 0); $mform->setType('course_id',PARAM_INT);

        $mform->addElement('html','<div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Nama</label>');
        $mform->addElement('text','kursus_nama','',['size'=>32]); $mform->setType('kursus_nama',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tempat</label>');
        $mform->addElement('text','kursus_tempat','',['size'=>20]); $mform->setType('kursus_tempat',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Mula</label>');
        $mform->addElement('date_selector','kursus_mula','');

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tamat</label>');
        $mform->addElement('date_selector','kursus_tamat','');

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Keputusan</label>');
        $mform->addElement('text','kursus_keputusan','',['size'=>16]); $mform->setType('kursus_keputusan',PARAM_TEXT);

        $mform->addElement('html','</div></div></div>');
        $g=[]; $g[]=$mform->createElement('submit','course_submit', empty($course_editrec)?'Tambah':'Kemaskini');
        $g[]=$mform->createElement('cancel','course_cancel','Bersih');
        $mform->addGroup($g,'course_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // PANGKAT – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header','sec_ranks',get_string('sec_ranks','local_studentinfo'));

        $html = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
        <thead class="thead-light"><tr>
          <th style="width:22%">Pangkat</th>
          <th style="width:14%">Tarikh</th>
          <th style="width:22%">Kekananan</th>
          <th style="width:14%">Tarikh Kekananan</th>
          <th style="width:14%">Tindakan</th>
        </tr></thead><tbody>';
        if ($rank_list) {
            foreach ($rank_list as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'rankaction'=>'edit', 'rid'=>$r->id], 'pane_sec_ranks');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'rankaction'=>'delete', 'rid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_ranks');
                $html .= '<tr>'.
                  '<td>'.s($r->pangkat ?? '').'</td>'.
                  '<td>'.($r->tarikh ? s(userdate($r->tarikh, get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td>'.s($r->kekananan ?? '').'</td>'.
                  '<td>'.($r->tarikh_kekananan ? s(userdate($r->tarikh_kekananan, get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="5" class="text-center text-muted">Tiada rekod pangkat.</td></tr>';
        }
        $html .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $html);

        // Add/Update Pangkat
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Pangkat</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden','rank_id',$rank_editrec->id ?? 0); $mform->setType('rank_id',PARAM_INT);

        $mform->addElement('html','<div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Pangkat</label>');
        $mform->addElement('text','rank_pangkat','',['size'=>24]); $mform->setType('rank_pangkat',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tarikh</label>');
        $mform->addElement('date_selector','rank_tarikh','');

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Kekananan</label>');
        $mform->addElement('text','rank_kekananan','',['size'=>18]); $mform->setType('rank_kekananan',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tarikh Kekananan</label>');
        $mform->addElement('date_selector','rank_tarikh_kekananan','');

        $mform->addElement('html','</div></div></div>');
        $g=[]; $g[]=$mform->createElement('submit','rank_submit', empty($rank_editrec)?'Tambah':'Kemaskini');
        $g[]=$mform->createElement('cancel','rank_cancel','Bersih');
        $mform->addGroup($g,'rank_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // PERTUKARAN – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header','sec_postings',get_string('sec_postings','local_studentinfo'));

        $html = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
        <thead class="thead-light"><tr>
          <th>Jawatan</th>
          <th style="width:18%">Pasukan</th>
          <th style="width:14%">Negeri</th>
          <th style="width:14%">Mula</th>
          <th style="width:14%">Tamat</th>
          <th style="width:14%">Tindakan</th>
        </tr></thead><tbody>';
        if ($post_list) {
            foreach ($post_list as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'postaction'=>'edit', 'pid'=>$r->id], 'pane_sec_postings');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'postaction'=>'delete', 'pid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_postings');
                $html .= '<tr>'.
                  '<td>'.s($r->jawatan ?? '').'</td>'.
                  '<td>'.s($r->pasukan ?? '').'</td>'.
                  '<td>'.s($r->negeri ?? '').'</td>'.
                  '<td>'.($r->mula  ? s(userdate($r->mula,  get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td>'.($r->tamat ? s(userdate($r->tamat, get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="6" class="text-center text-muted">Tiada rekod pertukaran.</td></tr>';
        }
        $html .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $html);

        // Add/Update Pertukaran
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Pertukaran</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden','post_id',$post_editrec->id ?? 0); $mform->setType('post_id',PARAM_INT);

        $mform->addElement('html','<div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Jawatan</label>');
        $mform->addElement('text','posting_jawatan','',['size'=>18]); $mform->setType('posting_jawatan',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Pasukan</label>');
        $mform->addElement('text','posting_pasukan','',['size'=>18]); $mform->setType('posting_pasukan',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Negeri</label>');
        $mform->addElement('text','posting_negeri','',['size'=>14]); $mform->setType('posting_negeri',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Mula</label>');
        $mform->addElement('date_selector','posting_mula','');

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tamat</label>');
        $mform->addElement('date_selector','posting_tamat','');

        $mform->addElement('html','</div></div></div>');
        $g=[]; $g[]=$mform->createElement('submit','post_submit', empty($post_editrec)?'Tambah':'Kemaskini');
        $g[]=$mform->createElement('cancel','post_cancel','Bersih');
        $mform->addGroup($g,'post_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // PINGAT – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header','sec_awards',get_string('sec_awards','local_studentinfo'));

        $html = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
        <thead class="thead-light"><tr>
          <th>Nama</th>
          <th style="width:16%">Singkatan</th>
          <th style="width:18%">Gelaran</th>
          <th style="width:14%">Tarikh</th>
          <th style="width:14%">Tindakan</th>
        </tr></thead><tbody>';
        if ($award_list) {
            foreach ($award_list as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'awardaction'=>'edit', 'awid'=>$r->id], 'pane_sec_awards');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'awardaction'=>'delete', 'awid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_awards');
                $html .= '<tr>'.
                  '<td>'.s($r->nama ?? '').'</td>'.
                  '<td>'.s($r->singkatan ?? '').'</td>'.
                  '<td>'.s($r->gelaran ?? '').'</td>'.
                  '<td>'.($r->tarikh ? s(userdate($r->tarikh, get_string('strftimedate','langconfig'))) : '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="5" class="text-center text-muted">Tiada rekod pingat.</td></tr>';
        }
        $html .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $html);

        // Add/Update Pingat
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Pingat</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden','award_id',$award_editrec->id ?? 0); $mform->setType('award_id',PARAM_INT);

        $mform->addElement('html','<div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Nama</label>');
        $mform->addElement('text','award_nama','',['size'=>24]); $mform->setType('award_nama',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Singkatan</label>');
        $mform->addElement('text','award_singkatan','',['size'=>16]); $mform->setType('award_singkatan',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Gelaran</label>');
        $mform->addElement('text','award_gelaran','',['size'=>16]); $mform->setType('award_gelaran',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-2"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Tarikh</label>');
        $mform->addElement('date_selector','award_tarikh','');

        $mform->addElement('html','</div></div></div>');
        $g=[]; $g[]=$mform->createElement('submit','award_submit', empty($award_editrec)?'Tambah':'Kemaskini');
        $g[]=$mform->createElement('cancel','award_cancel','Bersih');
        $mform->addGroup($g,'award_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // INSURAN – list + single-row form
        // ---------------------------------------------------------------------
        $mform->addElement('header','sec_insurance',get_string('sec_insurance','local_studentinfo'));

        $html = '<div class="card mb-2"><div class="card-body py-2"><div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
        <thead class="thead-light"><tr>
          <th>Penyedia</th>
          <th style="width:18%">Jumlah Unit</th>
          <th style="width:22%">No. Polisi</th>
          <th style="width:14%">Tindakan</th>
        </tr></thead><tbody>';
        if ($ins_list) {
            foreach ($ins_list as $r) {
                $editurl = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'insaction'=>'edit', 'insid'=>$r->id], 'pane_sec_insurance');
                $delurl  = new \moodle_url('/local/studentinfo/edit.php', ['userid'=>$user->id, 'insaction'=>'delete', 'insid'=>$r->id, 'sesskey'=>sesskey()], 'pane_sec_insurance');
                $html .= '<tr>'.
                  '<td>'.s($r->penyedia ?? '').'</td>'.
                  '<td>'.s(($r->jumlah_unit === null ? '' : $r->jumlah_unit)).'</td>'.
                  '<td>'.s($r->no_polis ?? '').'</td>'.
                  '<td><a class="btn btn-sm btn-outline-primary mr-1" href="'.$editurl.'">Edit</a>'.
                  '<a class="btn btn-sm btn-outline-danger" href="'.$delurl.'" onclick="return confirm(\'Padam rekod ini?\')">Delete</a></td>'.
                '</tr>';
            }
        } else {
            $html .= '<tr><td colspan="4" class="text-center text-muted">Tiada rekod insurans.</td></tr>';
        }
        $html .= '</tbody></table></div></div></div>';
        $mform->addElement('html', $html);

        // Add/Update Insuran
        $mform->addElement('html','<div class="card mb-3"><div class="card-header"><strong>Tambah / Kemaskini Insuran/Takaful</strong></div><div class="card-body"><div class="container-fluid"><div class="row">');
        $mform->addElement('hidden','ins_id',$ins_editrec->id ?? 0); $mform->setType('ins_id',PARAM_INT);

        $mform->addElement('html','<div class="col-md-4"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Penyedia</label>');
        $mform->addElement('text','ins_penyedia','',['size'=>24]); $mform->setType('ins_penyedia',PARAM_TEXT);

        $mform->addElement('html','</div></div><div class="col-md-3"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">Jumlah Unit</label>');
        $mform->addElement('text','ins_jumlah_unit','',['size'=>10]); $mform->setType('ins_jumlah_unit',PARAM_INT);

        $mform->addElement('html','</div></div><div class="col-md-5"><div class="form-group mb-2"><label class="form-label" style="font-weight:600;">No. Polisi</label>');
        $mform->addElement('text','ins_no_polis','',['size'=>24]); $mform->setType('ins_no_polis',PARAM_TEXT);

        $mform->addElement('html','</div></div></div>');
        $g=[]; $g[]=$mform->createElement('submit','ins_submit', empty($ins_editrec)?'Tambah':'Kemaskini');
        $g[]=$mform->createElement('cancel','ins_cancel','Bersih');
        $mform->addGroup($g,'ins_actions',' ',' ',false);
        $mform->addElement('html','</div></div>');

        // ---------------------------------------------------------------------
        // Save button
        // ---------------------------------------------------------------------
        $this->add_action_buttons(true, get_string('savechanges','local_studentinfo'));
    }

    public function validation($data, $files) {
        $errors = parent::validation($data, $files);

        $min = strtotime('1940-01-01'); $max = time();
        if (!empty($data['tarikh_lahir']) && ($data['tarikh_lahir'] < $min || $data['tarikh_lahir'] > $max)) {
            $errors['tarikh_lahir'] = 'Tarikh Lahir tidak logik (1940 hingga hari ini).';
        }
        if ($data['berat_kg'] !== '' && $data['berat_kg'] !== null && (!is_numeric($data['berat_kg']) || $data['berat_kg'] < 30 || $data['berat_kg'] > 200)) {
            $errors['berat_kg'] = 'Berat (kg) mesti antara 30 dan 200.';
        }
        if ($data['tinggi_m'] !== '' && $data['tinggi_m'] !== null && (!is_numeric($data['tinggi_m']) || $data['tinggi_m'] < 1.20 || $data['tinggi_m'] > 2.50)) {
            $errors['tinggi_m'] = 'Tinggi (m) mesti antara 1.20 dan 2.50.';
        }
        if ($data['bmi'] !== '' && $data['bmi'] !== null && (!is_numeric($data['bmi']) || $data['bmi'] < 10 || $data['bmi'] > 60)) {
            $errors['bmi'] = 'BMI di luar julat munasabah (10–60).';
        }

        // Optional: quick sanity checks for child single-row forms (non-blocking).
        if (!empty($data['course_submit'])) {
            if (!empty($data['kursus_tamat']) && !empty($data['kursus_mula']) && $data['kursus_tamat'] < $data['kursus_mula']) {
                $errors['kursus_tamat'] = 'Tarikh tamat tidak boleh lebih awal daripada tarikh mula.';
            }
        }
        if (!empty($data['post_submit'])) {
            if (!empty($data['posting_tamat']) && !empty($data['posting_mula']) && $data['posting_tamat'] < $data['posting_mula']) {
                $errors['posting_tamat'] = 'Tarikh tamat tidak boleh lebih awal daripada tarikh mula.';
            }
        }

        return $errors;
    }
}
