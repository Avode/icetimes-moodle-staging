<?php
$string['pluginname'] = 'Student Info';
$string['cap:view'] = 'View student info';
$string['cap:manage'] = 'Manage student info';
$string['cap:finance'] = 'Manage student finance';
$string['cap:discipline'] = 'Manage student discipline';
$string['dashboard'] = 'Student Dashboard';
$string['student'] = 'Student';
$string['bulkassign'] = 'Bulk Assign';
$string['cohorttools'] = 'Cohort Tools';
$string['gpasnapshot'] = 'GPA Snapshot';
$string['attnrollup'] = 'Attendance Rollup';
$string['uploadcsv'] = 'Upload CSV';
$string['csvhelp'] = 'CSV header: userid,programme_code,major_code,intake_code,admit_term_code,status';
$string['run'] = 'Run';
$string['execute'] = 'Execute';
$string['created'] = 'Created';
$string['updated'] = 'Updated';
$string['synced'] = 'Synced';
$string['success'] = 'Success';
$string['errors'] = 'Errors';
$string['manage'] = 'Manage Students';
$string['menu'] = 'Student Info';
$string['manage'] = 'Manage Student Info';
$string['view'] = 'View Student Info';
$string['edit'] = 'Edit Student Info';
$string['selectuser'] = 'Select user';
$string['search'] = 'Search';
$string['noresults'] = 'No records found.';
$string['savechanges'] = 'Save changes';
$string['cancel'] = 'Cancel';
$string['privacy:metadata'] = 'This plugin stores extended personal information linked to Moodle users.';

// Caps
$string['studentinfo:view'] = 'View student info';
$string['studentinfo:edit'] = 'Create/update student info';

// Fields - main
$string['pangkat'] = 'Pangkat';
$string['tentera_no'] = 'No. Tentera';
$string['perkhidmatan'] = 'Perkhidmatan (DARAT/LAUT/UDARA)';
$string['rejimen'] = 'Rejimen/Kor/Cawang';
$string['pengambilan'] = 'Pengambilan';
$string['tarikh_masuk'] = 'Tarikh Masuk Tentera';
$string['jenis_tauliah'] = 'Jenis Tauliah';
$string['tarikh_tauliah'] = 'Tarikh Tauliah';
$string['tarikh_tamat'] = 'Tarikh Tamat Perkhidmatan';
$string['tarikh_lahir'] = 'Tarikh Lahir';
$string['tempat_lahir'] = 'Tempat Lahir';
$string['berat_kg'] = 'Berat (kg)';
$string['tinggi_m'] = 'Tinggi (m)';
$string['bmi'] = 'BMI';
$string['darah'] = 'Kumpulan Darah';
$string['bangsa'] = 'Bangsa';
$string['agama'] = 'Agama';
$string['warganegara'] = 'Warganegara';
$string['taraf_kahwin'] = 'Taraf Perkahwinan';
$string['telefon'] = 'No. Telefon';
$string['email'] = 'E-mel';
$string['batd11_nilaian'] = 'BAT D 11: Nilaian';
$string['batd11_tahun'] = 'BAT D 11: Tahun';
$string['passport_no'] = 'No. Pasport';
$string['passport_expiry'] = 'Tamat Tempoh Pasport';
$string['negara_dilawati'] = 'Negara Asing Dilawati (comma/JSON)';
$string['hobi'] = 'Hobi';

// Sections
$string['sec_identity'] = 'Identiti & Perkhidmatan';
$string['sec_bio'] = 'DKT/Bio';
$string['sec_contact'] = 'Kontak';
$string['sec_perf'] = 'Prestasi & Ujian (ADFELPS)';
$string['sec_passport'] = 'Pasport & Perjalanan';
$string['sec_academic'] = 'Kelulusan Akademik';
$string['sec_language'] = 'Bahasa';
$string['sec_family'] = 'Waris (Pasangan/Anak)';
$string['sec_courses'] = 'Kursus Dihadiri';
$string['sec_ranks'] = 'Sejarah Pangkat';
$string['sec_postings'] = 'Pertukaran / Tumpangan';
$string['sec_awards'] = 'Pingat';
$string['sec_insurance'] = 'Insurans/Takaful';

// Repeaters (generic labels)
$string['tahun'] = 'Tahun';
$string['kelulusan'] = 'Kelulusan';
$string['bahasa'] = 'Bahasa';
$string['baca'] = 'Baca';
$string['lisan'] = 'Lisan';
$string['tulis'] = 'Tulis';
$string['hubungan'] = 'Hubungan';
$string['nama'] = 'Nama';
$string['ic'] = 'No. IC';
$string['alamat'] = 'Alamat';
$string['pekerjaan'] = 'Pekerjaan';
$string['jantina'] = 'Jantina';
$string['tarikh_lahir_child'] = 'Tarikh Lahir';

// Courses
$string['kursus_nama'] = 'Nama Kursus';
$string['kursus_tempat'] = 'Tempat';
$string['kursus_mula'] = 'Tarikh Mula';
$string['kursus_tamat'] = 'Tarikh Tamat';
$string['kursus_keputusan'] = 'Keputusan';

// Ranks
$string['rank_pangkat'] = 'Pangkat';
$string['rank_tarikh'] = 'Tarikh Pangkat';
$string['rank_kekananan'] = 'Kekananan Pangkat';
$string['rank_tarikh_kekananan'] = 'Tarikh Kekananan';

// Postings
$string['posting_jawatan'] = 'Jawatan';
$string['posting_pasukan'] = 'Pasukan';
$string['posting_negeri'] = 'Negeri';
$string['posting_mula'] = 'Tarikh Mula';
$string['posting_tamat'] = 'Tarikh Tamat';

// Awards
$string['award_nama'] = 'Nama Pingat';
$string['award_singkatan'] = 'Singkatan';
$string['award_gelaran'] = 'Gelaran';
$string['award_tarikh'] = 'Tarikh Anugerah';

// Insurance
$string['ins_penyedia'] = 'Penyedia';
$string['ins_jumlah_unit'] = 'Jumlah Unit';
$string['ins_no_polis'] = 'No. Ahli/Polisi';

//enrol
$string['intakeenrol'] = 'Enrol student to intake';
$string['labelintake'] = 'Intake';
$string['enrol'] = 'Enrol';
$string['studentaccountcreated'] = 'Student account created';
$string['studentenrolled'] = 'Student has been enrolled to the intake cohort.';
