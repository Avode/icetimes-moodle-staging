<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_studentinfo';
$plugin->version   = 2025082301;  // bump
$plugin->release   = '1.2.0';
$plugin->maturity  = MATURITY_STABLE;
$plugin->requires  = 2022112800;
