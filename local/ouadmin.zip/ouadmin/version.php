<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_ouadmin';
$plugin->version   = 2025112702;
$plugin->requires  = 2021051700; // Moodle 3.11 or later.
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.2';
