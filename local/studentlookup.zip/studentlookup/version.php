<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_studentlookup';
$plugin->version   = 2025112700;
$plugin->requires  = 2021051700; // Moodle 3.11 or later.
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1';

